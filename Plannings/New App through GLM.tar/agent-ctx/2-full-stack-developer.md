---
Task ID: 2
Agent: full-stack-developer
Task: Redesign DashboardTab.tsx with Premium IoT Dashboard Design

Work Log:
- Read existing worklog, store, globals.css, and current DashboardTab.tsx
- Completely rewrote /src/components/dashboard/DashboardTab.tsx with premium design
- Split DeviceCard into 4 type-specific card components: RelayCard, FanCard, LedCard, MasterCard
- Each card type has unique visual treatment with proper animations and interactions

Key Enhancements:
1. **Welcome Header**: Animated green glow behind username using framer-motion (opacity + scale pulse). Bell icon with spring-animated red badge showing unread count number.
2. **Stats Card (Bento)**: Radial gradient green glow at top-left corner. Inner top highlight line. Dividers between stat columns. Ping animation on live dot indicator. Hover border glow overlay.
3. **Room Chips**: whileTap scale animations on each chip. Refined active/inactive states.
4. **Device Grid**: Staggered entrance animations (delay: i * 0.04, scale + opacity).
5. **RelayCard**: Green bg icon container when ON, gradient power toggle, left border accent, bottom green gradient, relay badge with SlidersHorizontal icon.
6. **FanCard**: Spinning fan icon at variable speeds, 5-bar speed meter with varying heights and glow, "Speed X/5" indicator, +/- controls with whileTap animations.
7. **LedCard**: Amber color scheme throughout, filled lightbulb icon when ON, amber gradient toggle, warm amber ambient glow (boxShadow + radial gradient), "Illuminating"/"Off" status with animated amber dot.
8. **MasterCard**: Subtle dot pattern overlay, ring-1 green when ON, green radial glow, "All ON"/"All OFF" status, calls toggleMaster from store.

Lint: Passes with zero errors.
