import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function seed() {
  // Clean existing data
  await db.event.deleteMany();
  await db.schedule.deleteMany();
  await db.device.deleteMany();
  await db.room.deleteMany();
  await db.user.deleteMany();

  // Create User
  const user = await db.user.create({
    data: {
      email: "qadir@4layers.io",
      name: "qadir khan",
      password: "smart123",
    },
  });

  // Create Rooms
  const livingRoom = await db.room.create({
    data: { name: "Living Room", icon: "Sofa", userId: user.id },
  });
  const bedroom = await db.room.create({
    data: { name: "Bedroom", icon: "Bed", userId: user.id },
  });
  const kitchen = await db.room.create({
    data: { name: "Kitchen", icon: "CookingPot", userId: user.id },
  });
  const office = await db.room.create({
    data: { name: "Office", icon: "Monitor", userId: user.id },
  });

  // Living Room Devices
  const lr1 = await db.device.create({
    data: { name: "Switch 1", type: "relay", relayIndex: 1, isOn: true, roomId: livingRoom.id, userId: user.id, nodeMac: "AA:BB:CC:00:03:36" },
  });
  const lr2 = await db.device.create({
    data: { name: "Switch 2", type: "relay", relayIndex: 2, isOn: false, roomId: livingRoom.id, userId: user.id, nodeMac: "AA:BB:CC:00:03:36" },
  });
  const lr3 = await db.device.create({
    data: { name: "Switch 3", type: "relay", relayIndex: 3, isOn: true, roomId: livingRoom.id, userId: user.id, nodeMac: "AA:BB:CC:00:03:36" },
  });
  const lr4 = await db.device.create({
    data: { name: "Switch 4", type: "relay", relayIndex: 4, isOn: false, roomId: livingRoom.id, userId: user.id, nodeMac: "AA:BB:CC:00:03:36" },
  });
  const lrFan = await db.device.create({
    data: { name: "Ceiling Fan", type: "fan", fanSpeed: 3, isOn: true, roomId: livingRoom.id, userId: user.id, nodeMac: "AA:BB:CC:00:03:36" },
  });
  const lrLed = await db.device.create({
    data: { name: "LED Strip", type: "led", isOn: true, roomId: livingRoom.id, userId: user.id, nodeMac: "AA:BB:CC:00:03:36" },
  });
  const lrMaster = await db.device.create({
    data: { name: "Master Switch", type: "master", isOn: true, roomId: livingRoom.id, userId: user.id, nodeMac: "AA:BB:CC:00:03:36" },
  });

  // Bedroom Devices
  const br1 = await db.device.create({
    data: { name: "Switch 1", type: "relay", relayIndex: 1, isOn: true, roomId: bedroom.id, userId: user.id, nodeMac: "AA:BB:CC:00:04:42" },
  });
  const br2 = await db.device.create({
    data: { name: "Switch 2", type: "relay", relayIndex: 2, isOn: false, roomId: bedroom.id, userId: user.id, nodeMac: "AA:BB:CC:00:04:42" },
  });
  const brFan = await db.device.create({
    data: { name: "Ceiling Fan", type: "fan", fanSpeed: 2, isOn: true, roomId: bedroom.id, userId: user.id, nodeMac: "AA:BB:CC:00:04:42" },
  });
  const brLed = await db.device.create({
    data: { name: "LED Strip", type: "led", isOn: false, roomId: bedroom.id, userId: user.id, nodeMac: "AA:BB:CC:00:04:42" },
  });
  const brMaster = await db.device.create({
    data: { name: "Master Switch", type: "master", isOn: true, roomId: bedroom.id, userId: user.id, nodeMac: "AA:BB:CC:00:04:42" },
  });

  // Kitchen Devices
  const kt1 = await db.device.create({
    data: { name: "Switch 1", type: "relay", relayIndex: 1, isOn: true, roomId: kitchen.id, userId: user.id, nodeMac: "AA:BB:CC:00:05:19" },
  });
  const kt2 = await db.device.create({
    data: { name: "Switch 2", type: "relay", relayIndex: 2, isOn: false, roomId: kitchen.id, userId: user.id, nodeMac: "AA:BB:CC:00:05:19" },
  });
  const ktFan = await db.device.create({
    data: { name: "Exhaust Fan", type: "fan", fanSpeed: 0, isOn: false, roomId: kitchen.id, userId: user.id, nodeMac: "AA:BB:CC:00:05:19" },
  });
  const ktMaster = await db.device.create({
    data: { name: "Master Switch", type: "master", isOn: false, roomId: kitchen.id, userId: user.id, nodeMac: "AA:BB:CC:00:05:19" },
  });

  // Office Devices
  const of1 = await db.device.create({
    data: { name: "Switch 1", type: "relay", relayIndex: 1, isOn: true, roomId: office.id, userId: user.id, nodeMac: "AA:BB:CC:00:06:01" },
  });
  const of2 = await db.device.create({
    data: { name: "Switch 2", type: "relay", relayIndex: 2, isOn: true, roomId: office.id, userId: user.id, nodeMac: "AA:BB:CC:00:06:01" },
  });
  const ofFan = await db.device.create({
    data: { name: "Desk Fan", type: "fan", fanSpeed: 4, isOn: true, roomId: office.id, userId: user.id, nodeMac: "AA:BB:CC:00:06:01" },
  });
  const ofLed = await db.device.create({
    data: { name: "LED Strip", type: "led", isOn: true, roomId: office.id, userId: user.id, nodeMac: "AA:BB:CC:00:06:01" },
  });
  const ofMaster = await db.device.create({
    data: { name: "Master Switch", type: "master", isOn: true, roomId: office.id, userId: user.id, nodeMac: "AA:BB:CC:00:06:01" },
  });

  // Schedules
  await db.schedule.create({
    data: { deviceId: lr1.id, userId: user.id, action: "on", days: "daily", timeOn: "06:30", timeOff: "08:00", isEnabled: true },
  });
  await db.schedule.create({
    data: { deviceId: lr3.id, userId: user.id, action: "on", days: "mon,tue,wed,thu,fri", timeOn: "09:00", timeOff: "17:00", isEnabled: true },
  });
  await db.schedule.create({
    data: { deviceId: brLed.id, userId: user.id, action: "on", days: "daily", timeOn: "20:00", timeOff: "22:30", isEnabled: false },
  });
  await db.schedule.create({
    data: { deviceId: kt1.id, userId: user.id, action: "on", days: "daily", timeOn: "07:00", timeOff: "09:00", isEnabled: true },
  });
  await db.schedule.create({
    data: { deviceId: of1.id, userId: user.id, action: "off", days: "mon,tue,wed,thu,fri", timeOn: "18:00", isEnabled: true },
  });

  // Events
  const now = new Date();
  const eventTemplates = [
    { message: "Living Room Switch 1 turned ON at 06:30 AM (Schedule)", type: "success", deviceId: lr1.id, minutesAgo: 15 },
    { message: "Office Switchboard node connected successfully (Online)", type: "info", deviceId: of1.id, minutesAgo: 42 },
    { message: "Kitchen Fan speed changed to 4", type: "info", deviceId: ktFan.id, minutesAgo: 58 },
    { message: "Bedroom LED Strip turned ON", type: "success", deviceId: brLed.id, minutesAgo: 90 },
    { message: "Living Room Master Switch turned ON", type: "success", deviceId: lrMaster.id, minutesAgo: 120 },
    { message: "Office Switch 2 turned OFF (Schedule)", type: "info", deviceId: of2.id, minutesAgo: 180, isRead: true },
    { message: "New device PROV_000519 provisioned successfully", type: "success", deviceId: kt1.id, minutesAgo: 300, isRead: true },
    { message: "Kitchen Master Switch turned OFF", type: "warning", deviceId: ktMaster.id, minutesAgo: 360, isRead: true },
    { message: "Bedroom Ceiling Fan speed changed to 2", type: "info", deviceId: brFan.id, minutesAgo: 480, isRead: true },
    { message: "Living Room LED Strip turned ON", type: "success", deviceId: lrLed.id, minutesAgo: 600, isRead: true },
    { message: "Device PROV_000336 went offline briefly", type: "warning", deviceId: lr1.id, minutesAgo: 720, isRead: true },
    { message: "Schedule created for Office Switch 1", type: "info", deviceId: of1.id, minutesAgo: 1440, isRead: true },
  ];

  for (const evt of eventTemplates) {
    await db.event.create({
      data: {
        message: evt.message,
        type: evt.type,
        userId: user.id,
        deviceId: evt.deviceId,
        isRead: (evt as any).isRead ?? false,
        createdAt: new Date(now.getTime() - evt.minutesAgo * 60 * 1000),
      },
    });
  }

  console.log("✅ Seed data created successfully!");
  console.log(`   User: ${user.name}`);
  console.log(`   Rooms: 4`);
  console.log(`   Devices: ${4 + 5 + 4 + 5}`);
  console.log(`   Schedules: 5`);
  console.log(`   Events: ${eventTemplates.length}`);
}

seed()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
