import { db } from "./src/lib/db";

async function seed() {
  // Create user
  const user = await db.user.upsert({
    where: { email: "qadir@smartnest.io" },
    update: {},
    create: {
      email: "qadir@smartnest.io",
      name: "qadir khan",
      password: "smart123",
    },
  });

  // Create rooms
  const livingRoom = await db.room.create({
    data: { name: "Living Room", icon: "Sofa", userId: user.id },
  });
  const bedroom = await db.room.create({
    data: { name: "Bedroom", icon: "Bed", userId: user.id },
  });
  const kitchen = await db.room.create({
    data: { name: "Kitchen", icon: "CookingPot", userId: user.id },
  });
  const office = await db.room.create({
    data: { name: "Office", icon: "Monitor", userId: user.id },
  });

  // Create devices for Living Room
  await db.device.createMany({
    data: [
      { name: "Main Light", type: "relay", relayIndex: 1, isOn: true, roomId: livingRoom.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:01" },
      { name: "LED Strip", type: "led", relayIndex: 2, isOn: true, roomId: livingRoom.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:01" },
      { name: "AC Unit", type: "relay", relayIndex: 3, isOn: false, roomId: livingRoom.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:01" },
      { name: "Fan", type: "fan", fanSpeed: 3, isOn: true, roomId: livingRoom.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:01" },
      { name: "Master Switch", type: "master", isOn: true, roomId: livingRoom.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:01" },
    ],
  });

  // Create devices for Bedroom
  await db.device.createMany({
    data: [
      { name: "Ceiling Light", type: "relay", relayIndex: 1, isOn: false, roomId: bedroom.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:02" },
      { name: "Bedside Lamp", type: "led", relayIndex: 2, isOn: true, roomId: bedroom.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:02" },
      { name: "Fan", type: "fan", fanSpeed: 2, isOn: false, roomId: bedroom.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:02" },
      { name: "Master Switch", type: "master", isOn: false, roomId: bedroom.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:02" },
    ],
  });

  // Create devices for Kitchen
  await db.device.createMany({
    data: [
      { name: "Tube Light", type: "relay", relayIndex: 1, isOn: true, roomId: kitchen.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:03" },
      { name: "Exhaust Fan", type: "fan", fanSpeed: 1, isOn: true, roomId: kitchen.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:03" },
      { name: "Master Switch", type: "master", isOn: true, roomId: kitchen.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:03" },
    ],
  });

  // Create devices for Office
  await db.device.createMany({
    data: [
      { name: "Desk Lamp", type: "relay", relayIndex: 1, isOn: true, roomId: office.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:04" },
      { name: "Monitor Backlight", type: "led", relayIndex: 2, isOn: true, roomId: office.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:04" },
      { name: "Fan", type: "fan", fanSpeed: 0, isOn: false, roomId: office.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:04" },
      { name: "Master Switch", type: "master", isOn: true, roomId: office.id, userId: user.id, nodeMac: "AA:BB:CC:DD:EE:04" },
    ],
  });

  // Create some schedules
  const livingRoomDevices = await db.device.findMany({ where: { roomId: livingRoom.id }, take: 3 });
  if (livingRoomDevices[0]) {
    await db.schedule.create({
      data: {
        deviceId: livingRoomDevices[0].id,
        userId: user.id,
        action: "on",
        days: "Mon,Tue,Wed,Thu,Fri",
        timeOn: "08:30",
        timeOff: "22:00",
        isEnabled: true,
      },
    });
  }
  if (livingRoomDevices[2]) {
    await db.schedule.create({
      data: {
        deviceId: livingRoomDevices[2].id,
        userId: user.id,
        action: "on",
        days: "daily",
        timeOn: "14:00",
        timeOff: "18:00",
        isEnabled: true,
      },
    });
  }

  // Create events
  await db.event.createMany({
    data: [
      { message: "Living Room Main Light turned ON (Schedule)", type: "success", userId: user.id, deviceId: livingRoomDevices[0]?.id },
      { message: "Office Switchboard node connected successfully", type: "info", userId: user.id },
      { message: "Kitchen Fan speed changed to 4", type: "info", userId: user.id },
      { message: "Bedroom Ceiling Light turned OFF (Schedule)", type: "success", userId: user.id },
      { message: "Living Room LED Strip turned ON", type: "success", userId: user.id },
      { message: "New device PROV_000336 discovered nearby", type: "warning", userId: user.id },
      { message: "Bedroom Fan turned ON at speed 2", type: "info", userId: user.id },
      { message: "Kitchen Exhaust Fan turned ON", type: "success", userId: user.id },
      { message: "Office Desk Lamp turned ON (Manual)", type: "success", userId: user.id },
      { message: "Living Room AC Unit turned OFF (Schedule)", type: "info", userId: user.id },
    ],
  });

  console.log("Seed completed successfully!");
}

seed()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });