import { create } from "zustand";

export type TabId = "dashboard" | "add-device" | "timers" | "alerts" | "settings";

interface Room {
  id: string;
  name: string;
  icon: string;
}

interface Device {
  id: string;
  name: string;
  type: "relay" | "fan" | "led" | "master";
  relayIndex: number | null;
  fanSpeed: number;
  isOn: boolean;
  roomId: string;
  nodeMac: string | null;
  room?: Room;
}

interface Schedule {
  id: string;
  deviceId: string;
  device?: Device;
  action: string;
  days: string;
  timeOn: string | null;
  timeOff: string | null;
  isEnabled: boolean;
}

interface AlertEvent {
  id: string;
  message: string;
  type: "info" | "warning" | "success" | "error";
  isRead: boolean;
  createdAt: string;
  deviceName?: string;
}

interface AppState {
  // Navigation
  activeTab: TabId;
  setActiveTab: (tab: TabId) => void;

  // Data
  rooms: Room[];
  devices: Device[];
  schedules: Schedule[];
  events: AlertEvent[];
  unreadCount: number;

  // Filters
  selectedRoomId: string | null;
  setSelectedRoomId: (id: string | null) => void;

  // Actions
  setRooms: (rooms: Room[]) => void;
  setDevices: (devices: Device[]) => void;
  setSchedules: (schedules: Schedule[]) => void;
  setEvents: (events: AlertEvent[]) => void;
  setUnreadCount: (count: number) => void;

  // Device control
  toggleDevice: (deviceId: string) => void;
  setFanSpeed: (deviceId: string, speed: number) => void;
  toggleMaster: (roomId: string) => void;

  // Add device flow
  addDeviceStep: number;
  setAddDeviceStep: (step: number) => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  // Navigation
  activeTab: "dashboard",
  setActiveTab: (tab) => set({ activeTab: tab, addDeviceStep: tab === "add-device" ? 0 : 0 }),

  // Data
  rooms: [],
  devices: [],
  schedules: [],
  events: [],
  unreadCount: 0,

  // Filters
  selectedRoomId: null,
  setSelectedRoomId: (id) => set({ selectedRoomId: id }),

  // Setters
  setRooms: (rooms) => set({ rooms }),
  setDevices: (devices) => set({ devices }),
  setSchedules: (schedules) => set({ schedules }),
  setEvents: (events) => set({ events, unreadCount: events.filter((e) => !e.isRead).length }),
  setUnreadCount: (count) => set({ unreadCount: count }),

  // Device control
  toggleDevice: (deviceId) => {
    const { devices } = get();
    set({
      devices: devices.map((d) => {
        if (d.id === deviceId) {
          const newIsOn = !d.isOn;
          return { ...d, isOn: newIsOn };
        }
        return d;
      }),
    });
    // Fire API call in background
    fetch(`/api/devices/${deviceId}/toggle`, { method: "POST" }).catch(() => {});
  },

  setFanSpeed: (deviceId, speed) => {
    const { devices } = get();
    set({
      devices: devices.map((d) => {
        if (d.id === deviceId) {
          return { ...d, fanSpeed: speed, isOn: speed > 0 };
        }
        return d;
      }),
    });
    fetch(`/api/devices/${deviceId}/fan`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ speed }),
    }).catch(() => {});
  },

  toggleMaster: (roomId) => {
    const { devices } = get();
    const roomDevices = devices.filter((d) => d.roomId === roomId && d.type !== "master");
    const anyOn = roomDevices.some((d) => d.isOn);
    set({
      devices: devices.map((d) => {
        if (d.roomId === roomId) {
          return { ...d, isOn: !anyOn };
        }
        return d;
      }),
    });
    fetch(`/api/devices/master`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ roomId, isOn: !anyOn }),
    }).catch(() => {});
  },

  // Add device flow
  addDeviceStep: 0,
  setAddDeviceStep: (step) => set({ addDeviceStep: step }),
}));