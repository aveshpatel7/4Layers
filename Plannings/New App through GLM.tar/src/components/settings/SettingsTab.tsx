'use client';

import { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import {
  User,
  Mail,
  Lock,
  LogOut,
  Save,
  X,
  Shield,
  Smartphone,
  Eye,
  EyeOff,
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';

/* ── Types ──────────────────────────────────────────────────── */

interface UserData {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  createdAt: string;
  updatedAt: string;
}

/* ── Animation Variants ─────────────────────────────────────── */

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.05,
    },
  },
};

const fadeUp = {
  initial: { opacity: 0, y: 16, scale: 0.98 },
  animate: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] },
  },
};

const scaleIn = {
  initial: { opacity: 0, scale: 0.92 },
  animate: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.25, ease: 'easeOut' },
  },
  exit: {
    opacity: 0,
    scale: 0.95,
    transition: { duration: 0.15, ease: 'easeIn' },
  },
};

/* ── Helpers ────────────────────────────────────────────────── */

function getStrengthDots(password: string): [boolean, boolean, boolean] {
  const len = password.length;
  return [len >= 4, len >= 8, len >= 12];
}

function getStrengthLabel(password: string): string {
  const [one, two, three] = getStrengthDots(password);
  if (password.length === 0) return 'Enter a password';
  if (!one) return 'Too short';
  if (!two) return 'Weak';
  if (!three) return 'Good';
  return 'Strong';
}

function getStrengthColor(password: string): string {
  const [one, two, three] = getStrengthDots(password);
  if (!one) return 'text-nest-red';
  if (!two) return 'text-amber-400';
  if (!three) return 'text-nest-green';
  return 'text-nest-green';
}

function MemberSince({ dateStr }: { dateStr: string }) {
  const formatted = new Date(dateStr).toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
  });
  return (
    <span className="mt-1.5 inline-flex items-center gap-1.5 text-[11px] font-medium text-nest-muted/50 tracking-wider uppercase">
      <span className="h-px flex-1 max-w-4 bg-nest-border/60" />
      Member since {formatted}
    </span>
  );
}

/* ── Sub-Components ─────────────────────────────────────────── */

function PasswordEyeToggle({
  show,
  onToggle,
}: {
  show: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className="absolute right-3 top-1/2 -translate-y-1/2 p-0.5 rounded-md text-nest-muted/50 hover:text-nest-green hover:bg-nest-green-dim transition-smooth"
      aria-label={show ? 'Hide password' : 'Show password'}
    >
      {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
    </button>
  );
}

function StrengthIndicator({ password }: { password: string }) {
  const [one, two, three] = getStrengthDots(password);
  const filledCount = [one, two, three].filter(Boolean).length;

  return (
    <motion.div
      className="flex items-center gap-2 pt-2"
      initial={false}
      animate={{ opacity: password.length > 0 ? 1 : 0.5 }}
    >
      <div className="flex items-center gap-1.5">
        {[0, 1, 2].map((i) => {
          const active = [one, two, three][i];
          return (
            <motion.span
              key={i}
              className={`h-1.5 rounded-full transition-all duration-500 ${
                i === 0 ? 'w-6' : i === 1 ? 'w-8' : 'w-10'
              } ${
                active
                  ? 'bg-nest-green shadow-[0_0_8px_rgba(34,197,94,0.4)]'
                  : 'bg-nest-border/80'
              }`}
              layout
              transition={{ type: 'spring', stiffness: 400, damping: 30 }}
            />
          );
        })}
      </div>
      <motion.span
        className={`text-[10px] font-medium tracking-wide ${getStrengthColor(password)}`}
        key={getStrengthLabel(password)}
        initial={{ y: -4, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.2 }}
      >
        {getStrengthLabel(password)}
      </motion.span>
    </motion.div>
  );
}

function Spinner({ size = 'sm' }: { size?: 'sm' | 'md' }) {
  const s = size === 'sm' ? 'h-3.5 w-3.5' : 'h-4 w-4';
  return (
    <span
      className={`${s} animate-spin rounded-full border-2 border-white/20 border-t-white`}
    />
  );
}

/* ── Main Component ─────────────────────────────────────────── */

export function SettingsTab() {
  const [user, setUser] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);

  /* Profile editing */
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  /* Password change */
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);

  /* ── Fetch user ─────────────────────────────────────────── */
  const fetchUser = useCallback(async () => {
    try {
      const res = await fetch('/api/user');
      if (!res.ok) throw new Error('Failed to fetch user');
      const data: UserData = await res.json();
      setUser(data);
      setEditName(data.name);
      setEditEmail(data.email);
    } catch {
      toast.error('Failed to load user data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchUser();
  }, [fetchUser]);

  /* ── Save profile ───────────────────────────────────────── */
  const handleSaveProfile = async () => {
    if (!editName.trim() || !editEmail.trim()) {
      toast.error('Name and email are required');
      return;
    }
    setSavingProfile(true);
    try {
      const res = await fetch('/api/user', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: editName.trim(), email: editEmail.trim() }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to update profile');
      }
      const updated: UserData = await res.json();
      setUser(updated);
      setEditing(false);
      toast.success('Profile updated successfully');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to update profile');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleCancelEdit = () => {
    if (user) {
      setEditName(user.name);
      setEditEmail(user.email);
    }
    setEditing(false);
  };

  /* ── Change password ────────────────────────────────────── */
  const handleChangePassword = async () => {
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error('All password fields are required');
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error('New password and confirm password do not match');
      return;
    }
    setSavingPassword(true);
    try {
      const res = await fetch('/api/user', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to update password');
      }
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      toast.success('Password updated successfully');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Failed to update password');
    } finally {
      setSavingPassword(false);
    }
  };

  /* ── Logout ─────────────────────────────────────────────── */
  const handleLogout = () => {
    toast.success('Logged out successfully');
  };

  /* ── Loading Skeleton ───────────────────────────────────── */
  if (loading) {
    return (
      <div className="mx-auto max-w-lg space-y-5 px-5 pt-6 pb-24">
        {/* Profile skeleton */}
        <Skeleton className="h-[156px] w-full rounded-2xl bg-nest-card animate-shimmer" />
        {/* Password skeleton */}
        <Skeleton className="h-[340px] w-full rounded-2xl bg-nest-card animate-shimmer" />
        {/* App info skeleton */}
        <Skeleton className="h-[200px] w-full rounded-2xl bg-nest-card animate-shimmer" />
        {/* Logout skeleton */}
        <Skeleton className="h-12 w-full rounded-xl bg-nest-card animate-shimmer" />
      </div>
    );
  }

  const initial = user?.name?.charAt(0).toUpperCase() ?? 'U';

  return (
    <div className="mx-auto max-w-lg pb-24">
      <motion.div
        className="space-y-5 px-5 pt-6"
        variants={staggerContainer}
        initial="initial"
        animate="animate"
      >
        {/* ═══════════════════════════════════════════════════════
            SECTION 1 — Profile
        ═══════════════════════════════════════════════════════ */}
        <motion.section
          variants={fadeUp}
          className="glass-card relative overflow-hidden rounded-2xl border border-nest-border/60"
        >
          {/* Ambient glow */}
          <div className="pointer-events-none absolute -top-16 -right-16 h-40 w-40 rounded-full bg-nest-green/[0.06] blur-3xl" />
          <div className="pointer-events-none absolute -bottom-12 -left-12 h-32 w-32 rounded-full bg-nest-green/[0.04] blur-3xl" />

          <div className="relative p-5">
            <div className="flex items-start gap-4">
              {/* ── Avatar ─────────────────────────────────── */}
              <div className="relative shrink-0">
                {/* Glow ring */}
                <div className="absolute -inset-1 rounded-full bg-gradient-to-br from-nest-green/20 to-emerald-600/10 blur-md animate-pulse-glow" />
                <div className="relative flex h-18 w-18 items-center justify-center rounded-full bg-gradient-to-br from-nest-green via-emerald-500 to-emerald-600 text-2xl font-bold text-white shadow-xl shadow-nest-green/20 ring-2 ring-nest-green/20">
                  {initial}
                </div>
                {/* Online indicator */}
                <span className="absolute bottom-0 right-0 flex h-5 w-5 items-center justify-center">
                  <span className="absolute h-full w-full rounded-full bg-nest-green/40 animate-ping" />
                  <span className="relative h-3 w-3 rounded-full bg-nest-green border-[2.5px] border-nest-card shadow-[0_0_6px_rgba(34,197,94,0.6)]" />
                </span>
              </div>

              {/* ── Info / Edit ────────────────────────────── */}
              <div className="min-w-0 flex-1 pt-1">
                <AnimatePresence mode="wait">
                  {editing ? (
                    <motion.div
                      key="edit"
                      variants={scaleIn}
                      initial="initial"
                      animate="animate"
                      exit="exit"
                      className="space-y-3.5"
                    >
                      <div className="space-y-1.5">
                        <Label className="text-[10px] font-semibold text-nest-muted/70 uppercase tracking-[0.1em]">
                          Full Name
                        </Label>
                        <Input
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="h-10 rounded-lg border-nest-border/50 bg-nest-input/70 text-sm text-white placeholder:text-nest-muted/40 focus:border-nest-green/40 focus:ring-1 focus:ring-nest-green/20"
                          placeholder="Your name"
                          autoFocus
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-[10px] font-semibold text-nest-muted/70 uppercase tracking-[0.1em]">
                          Email Address
                        </Label>
                        <Input
                          value={editEmail}
                          onChange={(e) => setEditEmail(e.target.value)}
                          className="h-10 rounded-lg border-nest-border/50 bg-nest-input/70 text-sm text-white placeholder:text-nest-muted/40 focus:border-nest-green/40 focus:ring-1 focus:ring-nest-green/20"
                          placeholder="your@email.com"
                          type="email"
                        />
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="display"
                      variants={scaleIn}
                      initial="initial"
                      animate="animate"
                      exit="exit"
                    >
                      <h2 className="welcome-heading text-xl font-bold text-white leading-tight tracking-tight">
                        {user?.name ?? 'User'}
                      </h2>
                      <p className="mt-1 flex items-center gap-2 text-[13px] text-nest-muted/80">
                        <Mail className="h-3.5 w-3.5 text-nest-green/50" />
                        <span className="truncate">{user?.email ?? 'user@example.com'}</span>
                      </p>
                      {user?.createdAt && <MemberSince dateStr={user.createdAt} />}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* ── Action Buttons ──────────────────────────── */}
            <div className="mt-5 flex justify-end gap-2">
              <AnimatePresence mode="wait">
                {editing ? (
                  <motion.div
                    key="edit-actions"
                    className="flex gap-2"
                    variants={scaleIn}
                    initial="initial"
                    animate="animate"
                    exit="exit"
                  >
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleCancelEdit}
                      disabled={savingProfile}
                      className="h-9 rounded-lg px-3.5 text-xs font-medium text-nest-muted/70 hover:bg-white/[0.04] hover:text-white transition-smooth"
                    >
                      <X className="mr-1.5 h-3.5 w-3.5" />
                      Cancel
                    </Button>
                    <Button
                      size="sm"
                      onClick={handleSaveProfile}
                      disabled={savingProfile}
                      className="h-9 rounded-lg bg-gradient-to-r from-nest-green to-emerald-500 px-4 text-xs font-semibold text-white shadow-lg shadow-nest-green/20 hover:shadow-nest-green/30 hover:brightness-110 press-effect border-0"
                    >
                      {savingProfile ? (
                        <span className="flex items-center gap-2">
                          <Spinner />
                          Saving…
                        </span>
                      ) : (
                        <>
                          <Save className="mr-1.5 h-3.5 w-3.5" />
                          Save
                        </>
                      )}
                    </Button>
                  </motion.div>
                ) : (
                  <motion.div
                    key="view-actions"
                    variants={scaleIn}
                    initial="initial"
                    animate="animate"
                    exit="exit"
                  >
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditing(true)}
                      className="h-9 rounded-lg border-nest-border/60 bg-nest-surface/60 px-4 text-xs font-medium text-nest-muted/80 hover:bg-nest-green-dim hover:text-nest-green hover:border-nest-green/30 transition-smooth"
                    >
                      <User className="mr-1.5 h-3.5 w-3.5" />
                      Edit Profile
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </motion.section>

        {/* ═══════════════════════════════════════════════════════
            SECTION 2 — Change Password
        ═══════════════════════════════════════════════════════ */}
        <motion.section
          variants={fadeUp}
          className="glass-card relative overflow-hidden rounded-2xl border border-nest-border/60"
        >
          <div className="relative p-5">
            {/* Header */}
            <div className="mb-6 flex items-center gap-3.5">
              <div className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-nest-green-dim ring-1 ring-nest-green/10">
                <Shield className="h-5 w-5 text-nest-green" />
                <div className="absolute -inset-0.5 rounded-xl bg-nest-green/5 blur-sm" />
              </div>
              <div>
                <h3 className="text-[15px] font-semibold text-white tracking-tight">
                  Change Password
                </h3>
                <p className="mt-0.5 text-xs text-nest-muted/50 font-medium">
                  Keep your account secure
                </p>
              </div>
            </div>

            <div className="space-y-5">
              {/* Current Password */}
              <div className="space-y-2">
                <Label className="text-[10px] font-semibold text-nest-muted/70 uppercase tracking-[0.1em]">
                  Current Password
                </Label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-nest-muted/40" />
                  <Input
                    type={showCurrent ? 'text' : 'password'}
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="h-11 rounded-lg border-nest-border/40 bg-nest-input/50 pl-11 pr-11 text-sm text-white placeholder:text-nest-muted/30 focus:border-nest-green/30 focus:ring-1 focus:ring-nest-green/15 transition-smooth"
                    placeholder="Enter current password"
                  />
                  <PasswordEyeToggle
                    show={showCurrent}
                    onToggle={() => setShowCurrent(!showCurrent)}
                  />
                </div>
              </div>

              {/* New Password */}
              <div className="space-y-2">
                <Label className="text-[10px] font-semibold text-nest-muted/70 uppercase tracking-[0.1em]">
                  New Password
                </Label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-nest-muted/40" />
                  <Input
                    type={showNew ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="h-11 rounded-lg border-nest-border/40 bg-nest-input/50 pl-11 pr-11 text-sm text-white placeholder:text-nest-muted/30 focus:border-nest-green/30 focus:ring-1 focus:ring-nest-green/15 transition-smooth"
                    placeholder="Enter new password"
                  />
                  <PasswordEyeToggle
                    show={showNew}
                    onToggle={() => setShowNew(!showNew)}
                  />
                </div>
                <StrengthIndicator password={newPassword} />
              </div>

              {/* Confirm Password */}
              <div className="space-y-2">
                <Label className="text-[10px] font-semibold text-nest-muted/70 uppercase tracking-[0.1em]">
                  Confirm Password
                </Label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-nest-muted/40" />
                  <Input
                    type={showConfirm ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className={`h-11 rounded-lg border bg-nest-input/50 pl-11 pr-11 text-sm text-white placeholder:text-nest-muted/30 focus:ring-1 transition-smooth ${
                      confirmPassword.length > 0 && newPassword !== confirmPassword
                        ? 'border-nest-red/40 focus:border-nest-red/50 focus:ring-nest-red/15'
                        : 'border-nest-border/40 focus:border-nest-green/30 focus:ring-nest-green/15'
                    }`}
                    placeholder="Confirm new password"
                  />
                  <PasswordEyeToggle
                    show={showConfirm}
                    onToggle={() => setShowConfirm(!showConfirm)}
                  />
                </div>
                {confirmPassword.length > 0 && newPassword !== confirmPassword && (
                  <motion.p
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-[11px] font-medium text-nest-red/80"
                  >
                    Passwords do not match
                  </motion.p>
                )}
              </div>

              {/* Update Button */}
              <Button
                onClick={handleChangePassword}
                disabled={savingPassword}
                className="group relative mt-1 h-11 w-full rounded-xl bg-gradient-to-r from-nest-green to-emerald-500 text-sm font-semibold text-white shadow-lg shadow-nest-green/15 hover:shadow-nest-green/25 hover:brightness-110 press-effect border-0 overflow-hidden"
              >
                {/* Shine sweep on hover */}
                <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/10 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
                {savingPassword ? (
                  <span className="flex items-center gap-2">
                    <Spinner />
                    Updating…
                  </span>
                ) : (
                  <>
                    <Lock className="mr-2 h-4 w-4" />
                    Update Password
                  </>
                )}
              </Button>
            </div>
          </div>
        </motion.section>

        {/* ═══════════════════════════════════════════════════════
            SECTION 3 — App Info
        ═══════════════════════════════════════════════════════ */}
        <motion.section
          variants={fadeUp}
          className="glass-card relative overflow-hidden rounded-2xl border border-nest-border/60"
        >
          {/* Top gradient wash */}
          <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-nest-green/[0.05] via-nest-green/[0.02] to-transparent" />

          <div className="relative p-5">
            {/* Header */}
            <div className="mb-5 flex items-center gap-3.5">
              <div className="relative flex h-11 w-11 items-center justify-center rounded-xl bg-nest-green-dim ring-1 ring-nest-green/10">
                <Smartphone className="h-5 w-5 text-nest-green" />
                <div className="absolute -inset-0.5 rounded-xl bg-nest-green/5 blur-sm" />
              </div>
              <div>
                <h3 className="text-[15px] font-semibold text-white tracking-tight">
                  App Info
                </h3>
                <p className="mt-0.5 text-xs text-nest-muted/50 font-medium">
                  Application details
                </p>
              </div>
            </div>

            {/* Info rows */}
            <div className="rounded-xl border border-nest-border/40 bg-nest-surface/50 overflow-hidden">
              {/* App Name */}
              <div className="flex items-center justify-between px-4 py-3.5 transition-smooth hover:bg-white/[0.02]">
                <span className="text-[13px] text-nest-muted/70 font-medium">App Name</span>
                <span className="text-[13px] font-semibold text-white/90">
                  SmartNest by 4Layers
                </span>
              </div>
              <Separator className="bg-nest-border/40 mx-4 w-auto" />
              {/* Version */}
              <div className="flex items-center justify-between px-4 py-3.5 transition-smooth hover:bg-white/[0.02]">
                <span className="text-[13px] text-nest-muted/70 font-medium">Version</span>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-nest-green/10 px-3 py-1 text-[11px] font-bold text-nest-green ring-1 ring-nest-green/15 tracking-wide">
                  <span className="h-1.5 w-1.5 rounded-full bg-nest-green shadow-[0_0_4px_rgba(34,197,94,0.5)]" />
                  v2.0.0
                </span>
              </div>
              <Separator className="bg-nest-border/40 mx-4 w-auto" />
              {/* Platform */}
              <div className="flex items-center justify-between px-4 py-3.5 transition-smooth hover:bg-white/[0.02]">
                <span className="text-[13px] text-nest-muted/70 font-medium">Platform</span>
                <span className="text-[13px] font-semibold text-white/90">
                  Built for ESP32 IoT
                </span>
              </div>
            </div>
          </div>
        </motion.section>

        {/* ═══════════════════════════════════════════════════════
            SECTION 4 — Logout
        ═══════════════════════════════════════════════════════ */}
        <motion.div variants={fadeUp}>
          <Button
            variant="outline"
            onClick={handleLogout}
            className="group relative h-12 w-full rounded-xl border border-nest-red/15 bg-nest-red/[0.06] text-sm font-semibold text-nest-red/90 hover:bg-nest-red/15 hover:text-red-400 hover:border-nest-red/30 hover:shadow-[0_0_24px_rgba(239,68,68,0.08)] press-effect transition-smooth overflow-hidden"
          >
            {/* Red glow sweep on hover */}
            <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-nest-red/[0.04] to-transparent transition-transform duration-700 group-hover:translate-x-full" />
            <LogOut className="mr-2.5 h-4 w-4" />
            Log Out
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
}