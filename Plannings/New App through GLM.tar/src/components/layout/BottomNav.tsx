'use client';

import { useAppStore, type TabId } from '@/store/use-app-store';
import { LayoutDashboard, Plus, Clock, Bell, Settings } from 'lucide-react';
import { motion } from 'framer-motion';

const tabs: { id: TabId; label: string; icon: React.ElementType }[] = [
  { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
  { id: 'add-device', label: 'Add', icon: Plus },
  { id: 'timers', label: 'Timers', icon: Clock },
  { id: 'alerts', label: 'Alerts', icon: Bell },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function BottomNav() {
  const { activeTab, setActiveTab, unreadCount } = useAppStore();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50">
      {/* Depth gradient line at the very top of the nav */}
      <div className="h-px bg-gradient-to-r from-transparent via-nest-green/20 to-transparent" />

      {/* Frosted glass nav bar */}
      <div className="max-w-lg mx-auto bg-nest-surface/90 backdrop-blur-2xl backdrop-saturate-150 border-t border-white/[0.06]">
        <div className="flex items-center justify-around px-1 py-1">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            const Icon = tab.icon;
            const isAdd = tab.id === 'add-device';

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="relative flex flex-col items-center justify-center w-[60px] py-1.5 rounded-2xl transition-all duration-300"
              >
                {isAdd ? (
                  <motion.div
                    className="relative"
                    whileTap={{ scale: 0.9 }}
                  >
                    <div
                      className={`
                        w-12 h-12 rounded-2xl flex items-center justify-center
                        transition-all duration-300 ease-out
                        ${
                          isActive
                            ? 'bg-gradient-to-br from-nest-green to-emerald-600 shadow-lg shadow-nest-green/30 ring-2 ring-nest-green/20 ring-offset-2 ring-offset-nest-bg scale-110'
                            : 'bg-nest-green/12 hover:bg-nest-green/20'
                        }
                      `}
                    >
                      <Icon
                        className={`
                          w-5 h-5 transition-all duration-300
                          ${isActive ? 'text-white rotate-90' : 'text-nest-green'}
                        `}
                      />
                    </div>
                  </motion.div>
                ) : (
                  <>
                    <div className="relative flex items-center justify-center h-8">
                      <Icon
                        className={`
                          w-[22px] h-[22px] transition-all duration-300
                          ${
                            isActive
                              ? 'text-nest-green drop-shadow-[0_0_8px_rgba(34,197,94,0.6)]'
                              : 'text-nest-muted/40 hover:text-nest-muted/70'
                          }
                        `}
                      />
                      {tab.id === 'alerts' && unreadCount > 0 && (
                        <motion.span
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="absolute -top-1.5 -right-2.5 min-w-[18px] h-[18px] px-1 flex items-center justify-center bg-nest-red text-white text-[10px] font-bold rounded-full shadow-lg shadow-nest-red/30"
                        >
                          {unreadCount > 9 ? '9+' : unreadCount}
                        </motion.span>
                      )}
                    </div>
                    {isActive && (
                      <motion.div
                        layoutId="activeTabDot"
                        className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 bg-nest-green rounded-full shadow-[0_0_6px_rgba(34,197,94,0.8)]"
                        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                      />
                    )}
                    <span
                      className={`
                        text-[10px] mt-0.5 font-medium transition-all duration-300
                        ${isActive ? 'text-nest-green font-semibold' : 'text-nest-muted/40 hover:text-nest-muted/70'}
                      `}
                    >
                      {tab.label}
                    </span>
                  </>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Safe area for iOS */}
      <div className="max-w-lg mx-auto h-[env(safe-area-inset-bottom)] bg-nest-surface/90 backdrop-blur-2xl backdrop-saturate-150 border-t border-white/[0.06]" />
    </nav>
  );
}