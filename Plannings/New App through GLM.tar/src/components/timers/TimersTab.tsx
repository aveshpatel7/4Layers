'use client';

import { useAppStore } from '@/store/use-app-store';
import { Clock, Plus, Power, Calendar, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { useEffect, useState, useCallback } from 'react';
import { toast } from 'sonner';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const DAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

function formatTime12h(time: string | null): string {
  if (!time) return '—';
  const [h, m] = time.split(':').map(Number);
  const period = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 || 12;
  return `${hour12}:${String(m).padStart(2, '0')} ${period}`;
}

function formatDays(days: string): string {
  if (days === 'daily' || days === 'Daily' || days === 'everyday' || days === 'Everyday') {
    return 'Daily';
  }
  const parts = days.split(',').map((d) => d.trim());
  const allDays = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
  const selected = parts.map((d) => d.toLowerCase());

  if (selected.length === 7) return 'Daily';

  const abbreviated = selected.map((d) => {
    const idx = allDays.indexOf(d);
    return idx >= 0 ? DAY_LABELS[idx] : d;
  });
  return abbreviated.join(', ');
}

function parseDaysToIndices(days: string): number[] {
  if (!days) return [];
  if (days === 'daily' || days === 'Daily' || days === 'everyday' || days === 'Everyday') {
    return [0, 1, 2, 3, 4, 5, 6];
  }
  const allDays = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
  return days
    .split(',')
    .map((d) => d.trim().toLowerCase())
    .map((d) => allDays.indexOf(d))
    .filter((i) => i >= 0);
}

export function TimersTab() {
  const { schedules, devices, rooms, setSchedules } = useAppStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [creating, setCreating] = useState(false);

  // Form state
  const [formDeviceId, setFormDeviceId] = useState('');
  const [formAction, setFormAction] = useState('on');
  const [formTimeOn, setFormTimeOn] = useState('');
  const [formTimeOff, setFormTimeOff] = useState('');
  const [formDayMode, setFormDayMode] = useState<'daily' | 'custom'>('daily');
  const [formDays, setFormDays] = useState<boolean[]>([false, false, false, false, false, false, false]);

  const fetchSchedules = useCallback(async () => {
    try {
      const res = await fetch('/api/schedules');
      if (res.ok) {
        const data = await res.json();
        setSchedules(data);
      }
    } catch {
      // silently fail
    }
  }, [setSchedules]);

  useEffect(() => {
    fetchSchedules();
  }, [fetchSchedules]);

  const nonMasterDevices = devices.filter((d) => d.type !== 'master');

  const getRoomName = (deviceId: string) => {
    const device = devices.find((d) => d.id === deviceId);
    if (!device) return 'Unknown';
    if (device.room?.name) return device.room.name;
    return rooms.find((r) => r.id === device.roomId)?.name || 'Unknown';
  };

  const getDeviceName = (deviceId: string) => {
    const device = devices.find((d) => d.id === deviceId);
    return device?.name || 'Unknown Device';
  };

  const activeSchedules = schedules.filter((s) => s.isEnabled).length;

  const resetForm = () => {
    setFormDeviceId('');
    setFormAction('on');
    setFormTimeOn('');
    setFormTimeOff('');
    setFormDayMode('daily');
    setFormDays([false, false, false, false, false, false, false]);
  };

  const handleCreate = async () => {
    if (!formDeviceId || !formTimeOn) {
      toast.error('Please select a device and set a time');
      return;
    }

    const daysValue =
      formDayMode === 'daily'
        ? 'daily'
        : formDays
            .map((checked, i) => (checked ? DAY_LABELS[i].toLowerCase() : null))
            .filter(Boolean)
            .join(',');

    if (formDayMode !== 'daily' && !daysValue) {
      toast.error('Please select at least one day');
      return;
    }

    setCreating(true);
    try {
      const res = await fetch('/api/schedules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          deviceId: formDeviceId,
          action: formAction,
          timeOn: formTimeOn,
          timeOff: formTimeOff || null,
          days: daysValue,
        }),
      });

      if (res.ok) {
        toast.success('Schedule created successfully');
        setDialogOpen(false);
        resetForm();
        await fetchSchedules();
      } else {
        toast.error('Failed to create schedule');
      }
    } catch {
      toast.error('Failed to create schedule');
    } finally {
      setCreating(false);
    }
  };

  const handleToggle = async (scheduleId: string, currentState: boolean) => {
    const { schedules: current } = useAppStore.getState();
    setSchedules(
      current.map((s) =>
        s.id === scheduleId ? { ...s, isEnabled: !currentState } : s
      )
    );

    try {
      await fetch(`/api/schedules/${scheduleId}/toggle`, { method: 'POST' });
    } catch {
      const { schedules: latest } = useAppStore.getState();
      setSchedules(
        latest.map((s) =>
          s.id === scheduleId ? { ...s, isEnabled: currentState } : s
        )
      );
      toast.error('Failed to toggle schedule');
    }
  };

  const toggleDay = (i: number) => {
    setFormDays((prev) => {
      const next = [...prev];
      next[i] = !next[i];
      return next;
    });
  };

  return (
    <div className="flex flex-col gap-5 pb-24">
      {/* ─── Header ─── */}
      <header className="flex items-center justify-between px-5 pt-5 pb-1">
        <div className="flex items-center gap-3">
          <h1 className="text-lg font-bold text-white tracking-tight">
            Timers &amp; Schedules
          </h1>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-nest-green/12 text-nest-green border border-nest-green/15 transition-all">
            {activeSchedules} active
          </span>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <motion.button
              whileTap={{ scale: 0.92 }}
              className="w-10 h-10 rounded-xl bg-gradient-to-br from-nest-green to-emerald-600 flex items-center justify-center shadow-lg shadow-nest-green/25 press-effect"
            >
              <Plus className="w-5 h-5 text-white" />
            </motion.button>
          </DialogTrigger>

          {/* ─── Create Schedule Dialog ─── */}
          <DialogContent className="bg-nest-card/95 backdrop-blur-xl border border-nest-border/60 max-h-[85vh] overflow-y-auto shadow-2xl shadow-black/50">
            <DialogHeader>
              <DialogTitle className="text-white text-base font-bold tracking-tight">
                New Schedule
              </DialogTitle>
            </DialogHeader>

            <div className="flex flex-col gap-4 mt-2">
              {/* Device Select */}
              <div className="flex flex-col gap-2">
                <Label className="text-[11px] font-medium text-nest-muted uppercase tracking-wider">Device</Label>
                <Select value={formDeviceId} onValueChange={setFormDeviceId}>
                  <SelectTrigger className="w-full bg-nest-input/80 border-nest-border/60 text-white rounded-xl h-11 focus:ring-nest-green/30 focus:border-nest-green/40">
                    <SelectValue placeholder="Choose a device…" />
                  </SelectTrigger>
                  <SelectContent className="bg-nest-card border-nest-border/60 backdrop-blur-xl rounded-xl overflow-hidden">
                    {nonMasterDevices.map((device) => (
                      <SelectItem
                        key={device.id}
                        value={device.id}
                        className="text-white focus:bg-nest-green/10 focus:text-nest-green rounded-lg mx-1 my-0.5"
                      >
                        <span className="flex items-center gap-2">
                          <span className="truncate">{device.name}</span>
                          <span className="text-nest-muted text-[11px] shrink-0">· {getRoomName(device.id)}</span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Action Select */}
              <div className="flex flex-col gap-2">
                <Label className="text-[11px] font-medium text-nest-muted uppercase tracking-wider">Action</Label>
                <Select value={formAction} onValueChange={setFormAction}>
                  <SelectTrigger className="w-full bg-nest-input/80 border-nest-border/60 text-white rounded-xl h-11 focus:ring-nest-green/30 focus:border-nest-green/40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-nest-card border-nest-border/60 backdrop-blur-xl rounded-xl overflow-hidden">
                    <SelectItem value="on" className="text-white focus:bg-nest-green/10 focus:text-nest-green rounded-lg mx-1 my-0.5">
                      Turn ON
                    </SelectItem>
                    <SelectItem value="off" className="text-white focus:bg-nest-green/10 focus:text-nest-green rounded-lg mx-1 my-0.5">
                      Turn OFF
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Time ON */}
              <div className="flex flex-col gap-2">
                <Label className="text-[11px] font-medium text-nest-muted uppercase tracking-wider">Time ON</Label>
                <Input
                  type="time"
                  value={formTimeOn}
                  onChange={(e) => setFormTimeOn(e.target.value)}
                  className="bg-nest-input/80 border-nest-border/60 text-white rounded-xl h-11 font-mono focus:ring-nest-green/30 focus:border-nest-green/40"
                />
              </div>

              {/* Time OFF */}
              <div className="flex flex-col gap-2">
                <Label className="text-[11px] font-medium text-nest-muted uppercase tracking-wider">
                  Time OFF <span className="text-nest-muted/30 normal-case tracking-normal">(optional)</span>
                </Label>
                <Input
                  type="time"
                  value={formTimeOff}
                  onChange={(e) => setFormTimeOff(e.target.value)}
                  className="bg-nest-input/80 border-nest-border/60 text-white rounded-xl h-11 font-mono focus:ring-nest-green/30 focus:border-nest-green/40"
                />
              </div>

              {/* Day Mode */}
              <div className="flex flex-col gap-2">
                <Label className="text-[11px] font-medium text-nest-muted uppercase tracking-wider">Repeat</Label>
                <div className="flex gap-2">
                  {(['daily', 'custom'] as const).map((mode) => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => setFormDayMode(mode)}
                      className={`flex-1 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all duration-200 capitalize ${
                        formDayMode === mode
                          ? 'bg-nest-green/12 text-nest-green border border-nest-green/25 shadow-sm shadow-nest-green/10'
                          : 'bg-nest-input/80 border border-nest-border/60 text-nest-muted hover:text-white hover:border-nest-border'
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>

              {/* Day Picker */}
              <div className="flex flex-col gap-2">
                <Label className="text-[11px] font-medium text-nest-muted uppercase tracking-wider">Days</Label>
                <div className="flex flex-col gap-2 items-center">
                  <div className="grid grid-cols-3 gap-2 w-full">
                    {DAY_LABELS.slice(0, 3).map((day, i) => {
                      const isActive = formDayMode === 'daily' || formDays[i];
                      return (
                        <button
                          key={day}
                          type="button"
                          onClick={() => {
                            if (formDayMode === 'daily') setFormDayMode('custom');
                            toggleDay(i);
                          }}
                          className={`w-full py-2.5 rounded-lg text-xs font-semibold transition-all duration-200 ${
                            isActive
                              ? 'bg-nest-green/12 text-nest-green border border-nest-green/25'
                              : 'bg-nest-input/80 border border-nest-border/60 text-nest-muted hover:text-white hover:border-nest-border'
                          }`}
                        >
                          {day}
                        </button>
                      );
                    })}
                  </div>
                  <div className="grid grid-cols-4 gap-2 w-full">
                    {DAY_LABELS.slice(3, 7).map((day, i) => {
                      const idx = i + 3;
                      const isActive = formDayMode === 'daily' || formDays[idx];
                      return (
                        <button
                          key={day}
                          type="button"
                          onClick={() => {
                            if (formDayMode === 'daily') setFormDayMode('custom');
                            toggleDay(idx);
                          }}
                          className={`w-full py-2.5 rounded-lg text-xs font-semibold transition-all duration-200 ${
                            isActive
                              ? 'bg-nest-green/12 text-nest-green border border-nest-green/25'
                              : 'bg-nest-input/80 border border-nest-border/60 text-nest-muted hover:text-white hover:border-nest-border'
                          }`}
                        >
                          {day}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Create Button */}
              <button
                type="button"
                onClick={handleCreate}
                disabled={creating || !formDeviceId || !formTimeOn}
                className="w-full bg-gradient-to-br from-nest-green to-emerald-600 hover:from-nest-green/90 hover:to-emerald-600/90 disabled:opacity-30 disabled:cursor-not-allowed text-white font-semibold rounded-xl h-12 mt-1 press-effect shadow-lg shadow-nest-green/20"
              >
                {creating ? (
                  <span className="flex items-center justify-center gap-2">
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Creating…
                  </span>
                ) : (
                  'Create Schedule'
                )}
              </button>
            </div>
          </DialogContent>
        </Dialog>
      </header>

      {/* ─── Schedule List ─── */}
      <div className="px-5">
        {schedules.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col items-center justify-center py-20 text-center"
          >
            <div className="w-20 h-20 rounded-2xl bg-nest-surface border border-nest-border/60 flex items-center justify-center mb-5 animate-float">
              <Clock className="w-8 h-8 text-nest-muted/40" />
            </div>
            <p className="text-sm font-semibold text-white/70">No schedules yet</p>
            <p className="text-xs text-nest-muted/50 mt-1.5 max-w-[220px] leading-relaxed">
              Create automated routines to control your devices on a schedule
            </p>
          </motion.div>
        ) : (
          <div className="flex flex-col gap-3">
            {schedules.map((schedule, i) => {
              const deviceName = schedule.device?.name || getDeviceName(schedule.deviceId);
              const roomName = schedule.device?.room?.name || getRoomName(schedule.deviceId);
              const isOnAction = schedule.action === 'on' || schedule.action === 'ON';
              const dayIndices = parseDaysToIndices(schedule.days);
              const isDaily = dayIndices.length === 7;

              return (
                <motion.div
                  key={schedule.id}
                  initial={{ opacity: 0, y: 16, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={{ delay: i * 0.06, duration: 0.3, ease: 'easeOut' }}
                >
                  <div
                    className={`rounded-2xl border p-4 transition-all duration-300 ${
                      schedule.isEnabled
                        ? 'bg-nest-card/80 border-nest-border/60 border-l-2 border-l-nest-green shadow-sm shadow-black/20'
                        : 'bg-nest-card/30 border-nest-border/20 opacity-50'
                    }`}
                  >
                    {/* Top row */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3 min-w-0 flex-1">
                        <div
                          className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-all duration-300 ${
                            schedule.isEnabled
                              ? isOnAction
                                ? 'bg-nest-green-dim'
                                : 'bg-nest-red/12'
                              : 'bg-nest-border/20'
                          }`}
                        >
                          <Power
                            className={`w-4 h-4 transition-all duration-300 ${
                              schedule.isEnabled
                                ? isOnAction
                                  ? 'text-nest-green'
                                  : 'text-nest-red'
                                : 'text-nest-muted/30'
                            }`}
                          />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className={`text-sm font-semibold leading-tight truncate transition-all duration-300 ${
                              schedule.isEnabled ? 'text-white' : 'text-nest-muted/50'
                            }`}>
                              {deviceName}
                            </p>
                            <span className={`shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full transition-all duration-300 ${
                              isOnAction
                                ? 'bg-nest-green/12 text-nest-green'
                                : 'bg-nest-red/12 text-nest-red'
                            }`}>
                              {isOnAction ? 'Turn ON' : 'Turn OFF'}
                            </span>
                          </div>
                          <p className="text-[11px] text-nest-muted/60 mt-0.5">{roomName}</p>
                        </div>
                      </div>
                      <div className={`transition-all duration-300 ${
                        schedule.isEnabled ? 'drop-shadow-[0_0_8px_rgba(34,197,94,0.4)]' : ''
                      }`}>
                        <Switch
                          checked={schedule.isEnabled}
                          onCheckedChange={() => handleToggle(schedule.id, schedule.isEnabled)}
                        />
                      </div>
                    </div>

                    {/* Bottom row */}
                    <div className="flex items-center gap-4 mt-3 pt-3 border-t border-nest-border/30">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-nest-muted/50" />
                        <span className={`text-xs font-mono font-medium tracking-wide transition-all duration-300 ${
                          schedule.isEnabled ? 'text-white/90' : 'text-nest-muted/30'
                        }`}>
                          {formatTime12h(schedule.timeOn)}
                          {schedule.timeOff ? (
                            <>
                              <ChevronRight className="w-3 h-3 inline mx-0.5 text-nest-muted/30 align-middle" />
                              {formatTime12h(schedule.timeOff)}
                            </>
                          ) : null}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 min-w-0 overflow-hidden">
                        <Calendar className="w-3.5 h-3.5 text-nest-muted/50 shrink-0" />
                        {isDaily ? (
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold shrink-0 transition-all duration-300 ${
                            schedule.isEnabled
                              ? 'bg-nest-green/10 text-nest-green'
                              : 'bg-nest-border/30 text-nest-muted/40'
                          }`}>
                            Daily
                          </span>
                        ) : (
                          <div className="flex items-center gap-1 min-w-0 overflow-hidden">
                            {dayIndices.map((idx) => (
                              <span
                                key={idx}
                                className={`inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-semibold shrink-0 transition-all duration-300 ${
                                  schedule.isEnabled
                                    ? 'bg-nest-green/10 text-nest-green'
                                    : 'bg-nest-border/30 text-nest-muted/40'
                                }`}
                              >
                                {DAY_LABELS[idx]}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}