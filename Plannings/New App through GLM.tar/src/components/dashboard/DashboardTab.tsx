'use client';

import { useAppStore } from '@/store/use-app-store';
import {
  Bell,
  Power,
  Lightbulb,
  Fan as FanIcon,
  ToggleLeft,
  SlidersHorizontal,
  Plus,
  Minus,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useEffect, useState, useCallback } from 'react';

/* ═══════════════════════════════════════════════════════════════
   SmartNest — Premium Dashboard Tab
   Mobile-first · Dark theme · Micro-interactions
   ═══════════════════════════════════════════════════════════════ */

export function DashboardTab() {
  const {
    devices,
    rooms,
    selectedRoomId,
    setSelectedRoomId,
    toggleDevice,
    setFanSpeed,
    toggleMaster,
    unreadCount,
  } = useAppStore();

  const [userName, setUserName] = useState('qadir khan');

  useEffect(() => {
    fetch('/api/user')
      .then((r) => r.json())
      .then((data) => {
        if (data.name) setUserName(data.name);
      })
      .catch(() => {});
  }, []);

  /* ── Computed Stats ────────────────────────────────────────── */
  const nonMasterDevices = devices.filter((d) => d.type !== 'master');
  const totalDevices = nonMasterDevices.length;
  const devicesOn = nonMasterDevices.filter((d) => d.isOn).length;
  const activeRooms = new Set(
    nonMasterDevices.filter((d) => d.isOn).map((d) => d.roomId),
  ).size;

  /* ── Filtered Devices ──────────────────────────────────────── */
  const filteredDevices = selectedRoomId
    ? devices.filter((d) => d.roomId === selectedRoomId)
    : devices;

  /* ── Helpers ───────────────────────────────────────────────── */
  const getFanAnimClass = useCallback((speed: number) => {
    if (speed <= 0) return '';
    const classes: Record<number, string> = {
      1: 'animate-spin-slow',
      2: 'animate-spin-slow-2',
      3: 'animate-spin-slow-3',
      4: 'animate-spin-slow-4',
      5: 'animate-spin-slow-5',
    };
    return classes[speed] || 'animate-spin-slow-5';
  }, []);

  const getRoomName = useCallback(
    (roomId: string) => rooms.find((r) => r.id === roomId)?.name || 'Unknown',
    [rooms],
  );

  return (
    <div className="flex flex-col gap-5 pb-24">
      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
          SECTION 1 — Welcome Header
          ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <motion.header
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
        className="flex items-center justify-between px-5 pt-6 pb-1"
      >
        <div className="flex flex-col gap-0.5">
          <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-nest-muted/60">
            Welcome back
          </p>
          <h1 className="text-[22px] font-bold tracking-tight leading-none">
            <span className="relative inline-block">
              <span className="relative z-10 text-white">{userName}</span>
              {/* Animated green glow behind the name */}
              <motion.span
                className="absolute inset-0 blur-xl rounded-sm"
                style={{ backgroundColor: 'rgba(34, 197, 94, 0.25)' }}
                animate={{
                  opacity: [0.15, 0.35, 0.15],
                  scale: [0.95, 1.05, 0.95],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
              />
            </span>
          </h1>
        </div>

        {/* Notification Bell with red dot badge */}
        <motion.button
          whileTap={{ scale: 0.92 }}
          onClick={() => useAppStore.getState().setActiveTab('alerts')}
          className="relative w-11 h-11 rounded-2xl bg-nest-card border border-nest-border/70 flex items-center justify-center transition-smooth hover:bg-nest-border/40 hover:border-nest-border"
          aria-label={`Notifications${unreadCount > 0 ? ` — ${unreadCount} unread` : ''}`}
        >
          <Bell className="w-[18px] h-[18px] text-nest-muted transition-colors duration-200 hover:text-white" />
          {/* RED DOT badge showing unread count */}
          <AnimatePresence>
            {unreadCount > 0 && (
              <motion.span
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0, opacity: 0 }}
                transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                className="absolute -top-1 -right-1 min-w-[18px] h-[18px] rounded-full bg-red-500 flex items-center justify-center px-1 shadow-lg shadow-red-500/40"
              >
                <span className="text-[9px] font-bold text-white leading-none">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              </motion.span>
            )}
          </AnimatePresence>
        </motion.button>
      </motion.header>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
          SECTION 2 — Real-Time Stats Card (Bento)
          ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.08, ease: [0.25, 0.46, 0.45, 0.94] }}
        className="px-5"
      >
        <div
          className="relative bg-nest-card rounded-2xl border border-nest-border/80 p-5 overflow-hidden transition-smooth group hover:border-nest-green/20"
          style={{
            boxShadow:
              '0 0 40px -10px rgba(34, 197, 94, 0.08), inset 0 1px 0 rgba(255,255,255,0.03)',
          }}
        >
          {/* Top-left green gradient glow */}
          <div
            className="pointer-events-none absolute -top-10 -left-10 w-40 h-40 rounded-full opacity-30 blur-3xl"
            style={{
              background:
                'radial-gradient(circle, rgba(34,197,94,0.5) 0%, transparent 70%)',
            }}
          />
          {/* Subtle inner top highlight */}
          <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-nest-green/20 via-nest-green/5 to-transparent" />

          {/* Stats Row */}
          <div className="relative grid grid-cols-3 gap-3">
            {/* Total Devices */}
            <div className="flex flex-col items-center gap-1.5 py-1">
              <p className="text-[26px] font-bold text-white tabular-nums leading-none">
                {totalDevices}
              </p>
              <p className="text-[10px] font-medium text-nest-muted/70 uppercase tracking-wider">
                Devices
              </p>
            </div>

            {/* Divider */}
            <div className="relative flex flex-col items-center gap-1.5 py-1">
              <div className="absolute left-0 inset-y-2 w-px bg-nest-border/60" />
              <div className="absolute right-0 inset-y-2 w-px bg-nest-border/60" />
              <div className="flex items-center justify-center gap-2">
                <span className="w-[7px] h-[7px] rounded-full bg-nest-green animate-glow-pulse" />
                <p className="text-[26px] font-bold text-nest-green tabular-nums leading-none">
                  {devicesOn}
                </p>
              </div>
              <p className="text-[10px] font-medium text-nest-muted/70 uppercase tracking-wider">
                Online
              </p>
            </div>

            {/* Active Rooms */}
            <div className="flex flex-col items-center gap-1.5 py-1">
              <p className="text-[26px] font-bold text-white tabular-nums leading-none">
                {activeRooms}
              </p>
              <p className="text-[10px] font-medium text-nest-muted/70 uppercase tracking-wider">
                Rooms
              </p>
            </div>
          </div>

          {/* Live System Indicator */}
          <div className="relative flex items-center justify-center gap-2 mt-4 pt-3 border-t border-nest-border/40">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-nest-green/40 opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-nest-green" />
            </span>
            <span className="text-[10px] font-medium text-nest-muted/50 tracking-wide">
              Live &mdash; All systems operational
            </span>
          </div>

          {/* Hover border glow overlay */}
          <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none border border-nest-green/10" />
        </div>
      </motion.div>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
          SECTION 3 — Horizontal Room Chips (Scrollable)
          ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.14, ease: [0.25, 0.46, 0.45, 0.94] }}
        className="px-5"
      >
        <div className="flex gap-2.5 overflow-x-auto scroll-chips pb-1 -mx-5 px-5 no-scrollbar">
          {/* "All" Chip */}
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setSelectedRoomId(null)}
            className={`shrink-0 px-4.5 py-2 rounded-xl text-xs font-semibold transition-all duration-250 ${
              !selectedRoomId
                ? 'bg-nest-green text-white shadow-lg shadow-nest-green/25 ring-1 ring-nest-green/30'
                : 'bg-nest-card/80 border border-nest-border/50 text-nest-muted/70 hover:text-white hover:border-nest-muted/30'
            }`}
          >
            All
          </motion.button>

          {/* Room Chips */}
          {rooms.map((room) => {
            const isActive = selectedRoomId === room.id;
            return (
              <motion.button
                key={room.id}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedRoomId(room.id)}
                className={`shrink-0 px-4.5 py-2 rounded-xl text-xs font-semibold transition-all duration-250 ${
                  isActive
                    ? 'bg-nest-green text-white shadow-lg shadow-nest-green/25 ring-1 ring-nest-green/30'
                    : 'bg-nest-card/80 border border-nest-border/50 text-nest-muted/70 hover:text-white hover:border-nest-muted/30'
                }`}
              >
                {room.name}
              </motion.button>
            );
          })}
        </div>
      </motion.div>

      {/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
          SECTION 4 — 2-Column Device Grid
          ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="px-5"
      >
        {filteredDevices.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <div className="w-14 h-14 rounded-2xl bg-nest-card border border-nest-border/50 flex items-center justify-center">
              <Power className="w-6 h-6 text-nest-muted/40" />
            </div>
            <p className="text-sm text-nest-muted/60 font-medium">No devices found</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {filteredDevices.map((device, i) => (
              <motion.div
                key={device.id}
                initial={{ opacity: 0, y: 16, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{
                  delay: i * 0.04,
                  duration: 0.35,
                  ease: [0.25, 0.46, 0.45, 0.94],
                }}
              >
                <DeviceCard
                  device={device}
                  roomName={getRoomName(device.roomId)}
                  onToggle={() => {
                    if (device.type === 'master') {
                      toggleMaster(device.roomId);
                    } else {
                      toggleDevice(device.id);
                    }
                  }}
                  onFanSpeedChange={
                    device.type === 'fan'
                      ? (speed: number) => setFanSpeed(device.id, speed)
                      : undefined
                  }
                  getFanAnimClass={getFanAnimClass}
                />
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   Device Card — Type-Specific Renderers
   ═══════════════════════════════════════════════════════════════ */

interface DeviceCardProps {
  device: {
    id: string;
    name: string;
    type: 'relay' | 'fan' | 'led' | 'master';
    isOn: boolean;
    fanSpeed: number;
    roomId: string;
    relayIndex: number | null;
    room?: { name: string };
  };
  roomName: string;
  onToggle: () => void;
  onFanSpeedChange?: (speed: number) => void;
  getFanAnimClass: (speed: number) => string;
}

function DeviceCard({
  device,
  roomName,
  onToggle,
  onFanSpeedChange,
  getFanAnimClass,
}: DeviceCardProps) {
  const { type, isOn } = device;

  if (type === 'relay') return <RelayCard device={device} roomName={roomName} onToggle={onToggle} />;
  if (type === 'fan') return <FanCard device={device} roomName={roomName} onToggle={onToggle} onFanSpeedChange={onFanSpeedChange!} getFanAnimClass={getFanAnimClass} />;
  if (type === 'led') return <LedCard device={device} roomName={roomName} onToggle={onToggle} />;
  if (type === 'master') return <MasterCard device={device} roomName={roomName} onToggle={onToggle} />;
  return null;
}

/* ──────────────── RELAY CARD ──────────────── */

interface RelayCardProps {
  device: DeviceCardProps['device'] & { type: 'relay' };
  roomName: string;
  onToggle: () => void;
}

function RelayCard({ device, roomName, onToggle }: RelayCardProps) {
  const isOn = device.isOn;

  return (
    <motion.div
      whileTap={{ scale: 0.98 }}
      className={`device-card-hover relative rounded-2xl border p-4 flex flex-col gap-3 transition-all duration-300 overflow-hidden min-h-[152px] justify-between ${
        isOn
          ? 'bg-nest-card border-nest-border border-l-2 border-l-nest-green'
          : 'bg-nest-card/50 border-nest-border/40'
      }`}
    >
      {/* Subtle green gradient at bottom when ON */}
      {isOn && (
        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-nest-green/[0.06] to-transparent pointer-events-none rounded-b-2xl" />
      )}

      {/* Top Row: Icon + Toggle */}
      <div className="relative flex items-start justify-between">
        {/* Power icon in rounded container */}
        <div
          className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${
            isOn
              ? 'bg-nest-green/20 shadow-inner shadow-nest-green/10'
              : 'bg-nest-border/25'
          }`}
        >
          <Power
            className={`w-[18px] h-[18px] transition-colors duration-300 ${
              isOn ? 'text-nest-green' : 'text-nest-muted/50'
            }`}
          />
        </div>

        {/* Power Toggle — Green gradient when ON */}
        <motion.button
          whileTap={{ scale: 0.88 }}
          onClick={onToggle}
          className={`press-effect w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${
            isOn
              ? 'bg-gradient-to-br from-nest-green to-emerald-600 text-white shadow-lg shadow-nest-green/30'
              : 'bg-nest-border/30 text-nest-muted/50 hover:text-white hover:bg-nest-border/50'
          }`}
          aria-label={`Toggle ${device.name}`}
        >
          <Power className="w-4 h-4" />
        </motion.button>
      </div>

      {/* Middle: Device Info */}
      <div className="relative flex flex-col gap-0.5">
        <p className="text-[13px] font-semibold text-white leading-tight">{device.name}</p>
        <p className="text-[10px] text-nest-muted/60 font-medium">{roomName}</p>
      </div>

      {/* Bottom: Relay Badge */}
      <div className="relative">
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-nest-bg/60 border border-nest-border/30 text-[10px] text-nest-muted/60 font-medium">
          <SlidersHorizontal className="w-2.5 h-2.5" />
          Relay {device.relayIndex ?? 1}
        </span>
      </div>
    </motion.div>
  );
}

/* ──────────────── FAN CARD ──────────────── */

interface FanCardProps {
  device: DeviceCardProps['device'] & { type: 'fan' };
  roomName: string;
  onToggle: () => void;
  onFanSpeedChange: (speed: number) => void;
  getFanAnimClass: (speed: number) => string;
}

function FanCard({ device, roomName, onToggle, onFanSpeedChange, getFanAnimClass }: FanCardProps) {
  const isOn = device.isOn;
  const speed = device.fanSpeed;

  return (
    <motion.div
      whileTap={{ scale: 0.98 }}
      className={`device-card-hover relative rounded-2xl border p-4 flex flex-col gap-3 transition-all duration-300 overflow-hidden min-h-[192px] justify-between ${
        isOn
          ? 'bg-nest-card border-nest-border border-l-2 border-l-nest-green'
          : 'bg-nest-card/50 border-nest-border/40'
      }`}
    >
      {/* Bottom glow when ON */}
      {isOn && (
        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-nest-green/[0.06] to-transparent pointer-events-none rounded-b-2xl" />
      )}

      {/* Top Row: Fan Icon + Toggle */}
      <div className="relative flex items-start justify-between">
        {/* Fan icon — SPINS when ON */}
        <div
          className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${
            isOn
              ? 'bg-nest-green/20 shadow-inner shadow-nest-green/10'
              : 'bg-nest-border/25'
          }`}
        >
          <FanIcon
            className={`w-[18px] h-[18px] transition-colors duration-300 ${
              isOn ? 'text-nest-green' : 'text-nest-muted/50'
            } ${getFanAnimClass(speed)}`}
          />
        </div>

        {/* Power Toggle */}
        <motion.button
          whileTap={{ scale: 0.88 }}
          onClick={onToggle}
          className={`press-effect w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${
            isOn
              ? 'bg-gradient-to-br from-nest-green to-emerald-600 text-white shadow-lg shadow-nest-green/30'
              : 'bg-nest-border/30 text-nest-muted/50 hover:text-white hover:bg-nest-border/50'
          }`}
          aria-label={`Toggle ${device.name}`}
        >
          <Power className="w-4 h-4" />
        </motion.button>
      </div>

      {/* Device Info */}
      <div className="relative flex flex-col gap-0.5">
        <p className="text-[13px] font-semibold text-white leading-tight">{device.name}</p>
        <p className="text-[10px] text-nest-muted/60 font-medium">{roomName}</p>
      </div>

      {/* Speed Controls */}
      <div className="relative flex flex-col gap-2.5">
        {/* Speed Bar Meter — 5 bars */}
        <div className="flex items-end gap-[3px] h-3.5">
          {Array.from({ length: 5 }).map((_, idx) => {
            const filled = idx < speed;
            return (
              <motion.div
                key={idx}
                className="flex-1 rounded-full transition-colors duration-200"
                style={{
                  height: `${45 + idx * 11}%`,
                  backgroundColor: filled
                    ? 'rgba(34, 197, 94, 0.8)'
                    : 'rgba(255, 255, 255, 0.05)',
                  boxShadow: filled ? '0 0 6px rgba(34, 197, 94, 0.3)' : 'none',
                }}
                animate={{
                  backgroundColor: filled
                    ? 'rgba(34, 197, 94, 0.8)'
                    : 'rgba(255, 255, 255, 0.05)',
                }}
                transition={{ duration: 0.2 }}
              />
            );
          })}
        </div>

        {/* +/- Row with Speed Indicator */}
        <div className="flex items-center justify-between bg-nest-bg/70 rounded-xl px-2.5 py-1.5 border border-nest-border/20">
          <motion.button
            whileTap={{ scale: 0.85 }}
            onClick={(e) => {
              e.stopPropagation();
              onFanSpeedChange(Math.max(0, speed - 1));
            }}
            className="w-7 h-7 rounded-lg bg-nest-border/30 flex items-center justify-center text-nest-muted/60 hover:text-white hover:bg-nest-border/60 transition-colors duration-150"
            aria-label="Decrease fan speed"
          >
            <Minus className="w-3 h-3" strokeWidth={2.5} />
          </motion.button>

          <p
            className={`text-[11px] font-bold tabular-nums tracking-wide transition-colors duration-200 ${
              isOn ? 'text-nest-green' : 'text-nest-muted/50'
            }`}
          >
            Speed {speed}/5
          </p>

          <motion.button
            whileTap={{ scale: 0.85 }}
            onClick={(e) => {
              e.stopPropagation();
              onFanSpeedChange(Math.min(5, speed + 1));
            }}
            className="w-7 h-7 rounded-lg bg-nest-border/30 flex items-center justify-center text-nest-muted/60 hover:text-white hover:bg-nest-border/60 transition-colors duration-150"
            aria-label="Increase fan speed"
          >
            <Plus className="w-3 h-3" strokeWidth={2.5} />
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}

/* ──────────────── LED STRIP CARD ──────────────── */

interface LedCardProps {
  device: DeviceCardProps['device'] & { type: 'led' };
  roomName: string;
  onToggle: () => void;
}

function LedCard({ device, roomName, onToggle }: LedCardProps) {
  const isOn = device.isOn;

  return (
    <motion.div
      whileTap={{ scale: 0.98 }}
      className={`device-card-hover relative rounded-2xl border p-4 flex flex-col gap-3 transition-all duration-300 overflow-hidden min-h-[152px] justify-between ${
        isOn
          ? 'bg-nest-card border-nest-border border-l-2 border-l-amber-500/60'
          : 'bg-nest-card/50 border-nest-border/40'
      }`}
      style={
        isOn
          ? {
              boxShadow:
                '0 4px 28px -4px rgba(251, 191, 36, 0.15), inset 0 0 24px rgba(251, 191, 36, 0.03)',
            }
          : undefined
      }
    >
      {/* Warm amber ambient glow when ON */}
      {isOn && (
        <>
          <div
            className="pointer-events-none absolute -top-6 -right-6 w-24 h-24 rounded-full opacity-20 blur-2xl"
            style={{ background: 'radial-gradient(circle, rgba(251,191,36,0.6) 0%, transparent 70%)' }}
          />
          <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-amber-500/[0.04] to-transparent pointer-events-none rounded-b-2xl" />
        </>
      )}

      {/* Top Row: Lightbulb Icon + Toggle */}
      <div className="relative flex items-start justify-between">
        {/* Lightbulb icon — amber when ON */}
        <div
          className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${
            isOn
              ? 'bg-amber-500/15 shadow-inner shadow-amber-500/10'
              : 'bg-nest-border/25'
          }`}
        >
          <Lightbulb
            className={`w-[18px] h-[18px] transition-all duration-300 ${
              isOn ? 'text-amber-400' : 'text-nest-muted/50'
            }`}
            fill={isOn ? 'currentColor' : 'none'}
          />
        </div>

        {/* Separate ON/OFF Power Toggle */}
        <motion.button
          whileTap={{ scale: 0.88 }}
          onClick={onToggle}
          className={`press-effect w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${
            isOn
              ? 'bg-gradient-to-br from-amber-500 to-amber-600 text-white shadow-lg shadow-amber-500/25'
              : 'bg-nest-border/30 text-nest-muted/50 hover:text-white hover:bg-nest-border/50'
          }`}
          aria-label={`Toggle ${device.name}`}
        >
          <Power className="w-4 h-4" />
        </motion.button>
      </div>

      {/* Device Info */}
      <div className="relative flex flex-col gap-0.5">
        <p className="text-[13px] font-semibold text-white leading-tight">{device.name}</p>
        <p className="text-[10px] text-nest-muted/60 font-medium">{roomName}</p>
      </div>

      {/* Status: Illuminating / Off */}
      <div className="relative flex items-center gap-2">
        <span
          className={`w-[7px] h-[7px] rounded-full transition-all duration-500 ${
            isOn ? 'bg-amber-400 animate-glow-pulse' : 'bg-nest-muted/30'
          }`}
          style={
            isOn
              ? {
                  boxShadow: '0 0 8px rgba(251, 191, 36, 0.5)',
                }
              : undefined
          }
        />
        <span
          className={`text-[10px] font-semibold tracking-wide uppercase transition-colors duration-300 ${
            isOn ? 'text-amber-400/80' : 'text-nest-muted/40'
          }`}
        >
          {isOn ? 'Illuminating' : 'Off'}
        </span>
      </div>
    </motion.div>
  );
}

/* ──────────────── MASTER SWITCH CARD ──────────────── */

interface MasterCardProps {
  device: DeviceCardProps['device'] & { type: 'master' };
  roomName: string;
  onToggle: () => void;
}

function MasterCard({ device, roomName, onToggle }: MasterCardProps) {
  const isOn = device.isOn;

  return (
    <motion.div
      whileTap={{ scale: 0.98 }}
      className={`device-card-hover relative rounded-2xl border p-4 flex flex-col gap-3 transition-all duration-300 overflow-hidden min-h-[152px] justify-between ${
        isOn
          ? 'bg-nest-card border-nest-green/30 border-l-2 border-l-nest-green ring-1 ring-nest-green/10'
          : 'bg-nest-card/50 border-nest-border/40'
      }`}
    >
      {/* Subtle repeating dot pattern overlay */}
      <div
        className="absolute inset-0 opacity-[0.025] pointer-events-none rounded-2xl"
        style={{
          backgroundImage:
            'radial-gradient(circle, currentColor 0.8px, transparent 0.8px)',
          backgroundSize: '10px 10px',
        }}
      />

      {/* Top-left green glow when ON */}
      {isOn && (
        <div
          className="pointer-events-none absolute -top-8 -left-8 w-28 h-28 rounded-full opacity-20 blur-2xl"
          style={{ background: 'radial-gradient(circle, rgba(34,197,94,0.5) 0%, transparent 70%)' }}
        />
      )}

      {/* Bottom green gradient when ON */}
      {isOn && (
        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-nest-green/[0.06] to-transparent pointer-events-none rounded-b-2xl" />
      )}

      {/* Top Row: ToggleLeft Icon + Power Toggle */}
      <div className="relative flex items-start justify-between">
        <div
          className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${
            isOn
              ? 'bg-nest-green/20 shadow-inner shadow-nest-green/10'
              : 'bg-nest-border/25'
          }`}
        >
          <ToggleLeft
            className={`w-[18px] h-[18px] transition-colors duration-300 ${
              isOn ? 'text-nest-green' : 'text-nest-muted/50'
            }`}
          />
        </div>

        {/* Master Power Toggle */}
        <motion.button
          whileTap={{ scale: 0.88 }}
          onClick={onToggle}
          className={`press-effect w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300 ${
            isOn
              ? 'bg-gradient-to-br from-nest-green to-emerald-600 text-white shadow-lg shadow-nest-green/30'
              : 'bg-nest-border/30 text-nest-muted/50 hover:text-white hover:bg-nest-border/50'
          }`}
          aria-label={`Master toggle ${roomName}`}
        >
          <Power className="w-4 h-4" />
        </motion.button>
      </div>

      {/* Device Info */}
      <div className="relative flex flex-col gap-0.5">
        <p className="text-[13px] font-semibold text-white leading-tight">{device.name}</p>
        <p className="text-[10px] text-nest-muted/60 font-medium">{roomName}</p>
      </div>

      {/* Master Status */}
      <div className="relative flex items-center gap-2">
        <ToggleLeft
          className={`w-3 h-3 transition-colors duration-300 ${
            isOn ? 'text-nest-green' : 'text-nest-muted/40'
          }`}
        />
        <span
          className={`text-[10px] font-bold tracking-wide uppercase transition-colors duration-300 ${
            isOn ? 'text-nest-green/80' : 'text-nest-muted/40'
          }`}
        >
          {isOn ? 'All ON' : 'All OFF'}
        </span>
      </div>
    </motion.div>
  );
}