'use client';

import { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import {
  Bluetooth,
  QrCode,
  Keyboard,
  ArrowLeft,
  Wifi,
  Lock,
  Check,
  Circle,
  Loader2,
  Shield,
  Eye,
  EyeOff,
  Radio,
  ChevronRight,
  Zap,
  CheckCircle2,
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import { useAppStore } from '@/store/use-app-store';

// --- Mock data ---
const MOCK_DEVICES = [
  { name: 'PROV_000336', mac: 'AA:BB:CC:00:03:36', rssi: -45, pop: 'a1000336' },
  { name: 'PROV_000442', mac: 'AA:BB:CC:00:04:42', rssi: -62, pop: '12345678' },
  { name: 'PROV_000519', mac: 'AA:BB:CC:00:05:19', rssi: -78, pop: '12345678' },
];

const MOCK_WIFI = ['4Layers_5G', 'Home_WiFi', 'Neighbor_Net'];

const PROVISION_STEPS = [
  'Sending Wi-Fi credentials',
  'Applying Wi-Fi connection',
  'Checking provisioning status',
];

// ── Signal strength bars ──
function SignalBars({ rssi }: { rssi: number }) {
  const bars = 4;
  const strength = Math.max(1, Math.min(bars, Math.round(((rssi + 100) / 70) * bars)));
  const colorClass = strength >= 4 ? 'bg-nest-green' : strength >= 3 ? 'bg-nest-green' : strength >= 2 ? 'bg-amber-400' : 'bg-nest-red';

  return (
    <div className="flex items-end gap-[2px] h-4">
      {Array.from({ length: bars }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ scaleY: 0 }}
          animate={{ scaleY: 1 }}
          transition={{ delay: i * 0.08, duration: 0.3 }}
          className={`w-[3px] rounded-full origin-bottom ${
            i < strength ? colorClass : 'bg-white/10'
          }`}
          style={{ height: `${(i + 1) * 6}px` }}
        />
      ))}
    </div>
  );
}

// ── Step indicator (dots) ──
function StepDots({ current, total }: { current: number; total: number }) {
  return (
    <div className="flex items-center justify-center gap-1.5 py-2">
      {Array.from({ length: total }).map((_, i) => (
        <motion.div
          key={i}
          animate={{
            width: i === current ? 20 : 6,
            backgroundColor: i <= current ? '#22C55E' : 'rgba(255,255,255,0.1)',
          }}
          transition={{ type: 'spring', stiffness: 400, damping: 25 }}
          className="h-[6px] rounded-full"
        />
      ))}
    </div>
  );
}

// ── Slide variants ──
const slideVariants = {
  enter: (direction: number) => ({ x: direction > 0 ? 300 : -300, opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (direction: number) => ({ x: direction > 0 ? -300 : 300, opacity: 0 }),
};

// ── Entry Screen (Step 0) ──
function EntryStep({ onSelect }: { onSelect: (step: number) => void }) {
  const options = [
    {
      step: 1,
      icon: Bluetooth,
      title: 'Provision via Bluetooth',
      subtitle: 'Scan & connect nearby ESP32 devices',
      badge: 'Recommended',
      color: 'text-nest-green',
      iconBg: 'bg-nest-green-dim',
    },
    {
      step: 1,
      icon: QrCode,
      title: 'Scan Device QR Code',
      subtitle: 'Point camera at device QR label',
      badge: null,
      color: 'text-nest-amber',
      iconBg: 'bg-amber-500/10',
    },
    {
      step: 1,
      icon: Keyboard,
      title: 'Add Node Manually',
      subtitle: 'Enter device MAC address manually',
      badge: null,
      color: 'text-blue-400',
      iconBg: 'bg-blue-400/10',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.35 }}
      className="flex flex-col gap-4"
    >
      <div className="text-center mb-2">
        <div className="w-16 h-16 rounded-2xl bg-nest-green-dim flex items-center justify-center mx-auto mb-4 animate-float">
          <Zap className="w-7 h-7 text-nest-green" />
        </div>
        <h2 className="text-lg font-bold text-white">Add New Device</h2>
        <p className="text-xs text-nest-muted/70 mt-1">Choose a method to pair your SmartNest device</p>
      </div>

      {options.map((opt, i) => {
        const Icon = opt.icon;
        return (
          <motion.button
            key={opt.title}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + i * 0.08, duration: 0.3 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelect(opt.step)}
            className="w-full flex items-center gap-4 p-4 rounded-2xl bg-nest-card/70 border border-nest-border/60 hover:border-nest-green/20 hover:bg-nest-card transition-all duration-200 group text-left"
          >
            <div className={`w-12 h-12 rounded-xl ${opt.iconBg} flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-200`}>
              <Icon className={`w-5 h-5 ${opt.color}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-sm font-semibold text-white">{opt.title}</p>
                {opt.badge && (
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-nest-green/15 text-nest-green border border-nest-green/20">
                    {opt.badge}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-nest-muted/60 mt-0.5">{opt.subtitle}</p>
            </div>
            <ChevronRight className="w-4 h-4 text-nest-muted/30 group-hover:text-nest-muted/60 group-hover:translate-x-0.5 transition-all duration-200" />
          </motion.button>
        );
      })}
    </motion.div>
  );
}

// ── BLE Scan Screen (Step 1) ──
function ScanStep({
  selected,
  onSelect,
}: {
  selected: string | null;
  onSelect: (name: string) => void;
}) {
  const [scanning, setScanning] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setScanning(false), 2500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="flex flex-col gap-4">
      <div className="text-center mb-1">
        <motion.div
          animate={{ scale: scanning ? [1, 1.1, 1] : 1 }}
          transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
          className="w-14 h-14 rounded-2xl bg-nest-green-dim flex items-center justify-center mx-auto mb-3"
        >
          <Bluetooth className="w-6 h-6 text-nest-green" />
        </motion.div>
        <h2 className="text-base font-bold text-white">
          {scanning ? 'Scanning for Devices...' : 'Devices Found'}
        </h2>
        <p className="text-[11px] text-nest-muted/60 mt-1">
          {scanning ? 'Looking for nearby unconfigured ESP32 boards' : 'Tap a device to select it'}
        </p>
      </div>

      {scanning && (
        <div className="flex justify-center py-6">
          <Loader2 className="w-6 h-6 text-nest-green animate-spin" />
        </div>
      )}

      <AnimatePresence>
        {!scanning && MOCK_DEVICES.map((device, i) => (
          <motion.button
            key={device.name}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ delay: i * 0.1, duration: 0.3 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelect(device.name)}
            className={`w-full flex items-center gap-4 p-4 rounded-2xl border transition-all duration-200 text-left ${
              selected === device.name
                ? 'bg-nest-green/8 border-nest-green/40 shadow-lg shadow-nest-green/10'
                : 'bg-nest-card/70 border-nest-border/60 hover:border-nest-border'
            }`}
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              selected === device.name ? 'bg-nest-green-dim' : 'bg-nest-border/40'
            }`}>
              <Radio className={`w-4 h-4 ${selected === device.name ? 'text-nest-green' : 'text-nest-muted'}`} />
            </div>
            <div className="flex-1 min-w-0">
              <p className={`text-sm font-semibold ${selected === device.name ? 'text-nest-green' : 'text-white'}`}>
                {device.name}
              </p>
              <p className="text-[10px] text-nest-muted/50 font-mono mt-0.5">{device.mac}</p>
            </div>
            <SignalBars rssi={device.rssi} />
            {selected === device.name && (
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                <CheckCircle2 className="w-5 h-5 text-nest-green" />
              </motion.div>
            )}
          </motion.button>
        ))}
      </AnimatePresence>
    </div>
  );
}

// ── PoP Verification Screen (Step 2) ──
function PopStep({
  deviceName,
  onVerified,
}: {
  deviceName: string;
  onVerified: () => void;
}) {
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const device = MOCK_DEVICES.find(d => d.name === deviceName);

  const handleVerify = () => {
    if (!pin) return;
    setVerifying(true);
    setTimeout(() => {
      const isCorrect = pin === device?.pop;
      if (isCorrect) {
        toast.success('PIN verified successfully');
        onVerified();
      } else {
        toast.error('Invalid PIN. Please try again.');
      }
      setVerifying(false);
    }, 1200);
  };

  return (
    <div className="flex flex-col gap-5">
      <div className="text-center">
        <div className="w-14 h-14 rounded-2xl bg-nest-green-dim flex items-center justify-center mx-auto mb-3">
          <Shield className="w-6 h-6 text-nest-green" />
        </div>
        <h2 className="text-base font-bold text-white">Security Verification</h2>
        <p className="text-[11px] text-nest-muted/60 mt-1">Enter the Proof of Possession PIN printed on your device</p>
      </div>

      <div className="bg-nest-card/70 border border-nest-border/60 rounded-2xl p-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-9 h-9 rounded-lg bg-nest-border/40 flex items-center justify-center">
            <Radio className="w-4 h-4 text-nest-green" />
          </div>
          <div>
            <p className="text-sm font-semibold text-white">{deviceName}</p>
            <p className="text-[10px] text-nest-muted/50 font-mono">{device?.mac}</p>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[11px] font-medium text-nest-muted uppercase tracking-wider">PoP PIN</label>
          <div className="relative">
            <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-nest-muted/50" />
            <Input
              type={showPin ? 'text' : 'password'}
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="Enter PIN (e.g. a1000336)"
              className="bg-nest-input/80 border-nest-border/60 text-white font-mono pl-11 pr-10 rounded-xl h-11 text-sm focus:border-nest-green/40 focus:ring-nest-green/20 placeholder:text-nest-muted/30"
              onKeyDown={(e) => e.key === 'Enter' && handleVerify()}
            />
            <button
              type="button"
              onClick={() => setShowPin(!showPin)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-nest-muted hover:text-nest-green transition-colors"
            >
              {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </div>

      <button
        onClick={handleVerify}
        disabled={!pin || verifying}
        className="w-full bg-gradient-to-br from-nest-green to-emerald-600 hover:from-nest-green/90 hover:to-emerald-600/90 disabled:opacity-30 disabled:cursor-not-allowed text-white font-semibold rounded-xl h-12 press-effect transition-all duration-200 shadow-lg shadow-nest-green/20"
      >
        {verifying ? (
          <span className="flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin" />
            Verifying...
          </span>
        ) : (
          'Verify & Continue'
        )}
      </button>
    </div>
  );
}

// ── WiFi Connection Screen (Step 3) ──
function WifiStep({ onConnected }: { onConnected: () => void }) {
  const [ssid, setSsid] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [connecting, setConnecting] = useState(false);

  const handleApply = () => {
    if (!ssid || !password) return;
    setConnecting(true);
    setTimeout(() => {
      toast.success('WiFi credentials applied');
      onConnected();
      setConnecting(false);
    }, 1500);
  };

  return (
    <div className="flex flex-col gap-5">
      <div className="text-center">
        <div className="w-14 h-14 rounded-2xl bg-nest-green-dim flex items-center justify-center mx-auto mb-3">
          <Wifi className="w-6 h-6 text-nest-green" />
        </div>
        <h2 className="text-base font-bold text-white">Connect to WiFi</h2>
        <p className="text-[11px] text-nest-muted/60 mt-1">Select your network and enter the password</p>
      </div>

      <div className="bg-nest-card/70 border border-nest-border/60 rounded-2xl p-4 space-y-4">
        {/* SSID Selection */}
        <div className="space-y-2">
          <label className="text-[11px] font-medium text-nest-muted uppercase tracking-wider">WiFi Network</label>
          <Select value={ssid} onValueChange={setSsid}>
            <SelectTrigger className="w-full bg-nest-input/80 border-nest-border/60 text-white rounded-xl h-11 transition-all focus:border-nest-green/40 focus:ring-nest-green/20">
              <Wifi className="w-4 h-4 text-nest-muted/50 mr-2" />
              <SelectValue placeholder="Select a network..." />
            </SelectTrigger>
            <SelectContent className="bg-nest-card border-nest-border/60 backdrop-blur-xl rounded-xl overflow-hidden">
              {MOCK_WIFI.map((wifi) => (
                <SelectItem
                  key={wifi}
                  value={wifi}
                  className="text-white focus:bg-nest-green/10 focus:text-nest-green rounded-lg mx-1 my-0.5"
                >
                  {wifi}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Password */}
        <div className="space-y-2">
          <label className="text-[11px] font-medium text-nest-muted uppercase tracking-wider">Password</label>
          <div className="relative">
            <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-nest-muted/50" />
            <Input
              type={showPass ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter WiFi password"
              className="bg-nest-input/80 border-nest-border/60 text-white pl-11 pr-10 rounded-xl h-11 text-sm focus:border-nest-green/40 focus:ring-nest-green/20 placeholder:text-nest-muted/30"
              onKeyDown={(e) => e.key === 'Enter' && handleApply()}
            />
            <button
              type="button"
              onClick={() => setShowPass(!showPass)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-nest-muted hover:text-nest-green transition-colors"
            >
              {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </div>

      <button
        onClick={handleApply}
        disabled={!ssid || !password || connecting}
        className="w-full bg-gradient-to-br from-nest-green to-emerald-600 hover:from-nest-green/90 hover:to-emerald-600/90 disabled:opacity-30 disabled:cursor-not-allowed text-white font-semibold rounded-xl h-12 press-effect transition-all duration-200 shadow-lg shadow-nest-green/20"
      >
        {connecting ? (
          <span className="flex items-center justify-center gap-2">
            <Loader2 className="w-4 h-4 animate-spin" />
            Applying...
          </span>
        ) : (
          'Apply WiFi Credentials'
        )}
      </button>
    </div>
  );
}

// ── Progress Checklist Screen (Step 4) ──
function ProgressStep({ onComplete }: { onComplete: () => void }) {
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [allDone, setAllDone] = useState(false);

  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];
    PROVISION_STEPS.forEach((_, i) => {
      timers.push(
        setTimeout(() => {
          setCompletedSteps((prev) => [...prev, i]);
          if (i === PROVISION_STEPS.length - 1) {
            setTimeout(() => setAllDone(true), 600);
          }
        }, (i + 1) * 1500)
      );
    });
    return () => timers.forEach(clearTimeout);
  }, []);

  return (
    <div className="flex flex-col gap-6">
      <div className="text-center">
        <motion.div
          animate={allDone ? { scale: [1, 1.15, 1] } : {}}
          transition={{ duration: 0.5 }}
          className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-3 ${
            allDone ? 'bg-nest-green-dim' : 'bg-nest-border/40'
          }`}
        >
          {allDone ? (
            <CheckCircle2 className="w-7 h-7 text-nest-green" />
          ) : (
            <Loader2 className="w-7 h-7 text-nest-green animate-spin" />
          )}
        </motion.div>
        <h2 className="text-base font-bold text-white">
          {allDone ? 'Provisioning Complete!' : 'Provisioning Device...'}
        </h2>
        <p className="text-[11px] text-nest-muted/60 mt-1">
          {allDone ? 'Your device is connected and ready' : 'Please wait while we configure your device'}
        </p>
      </div>

      <div className="bg-nest-card/70 border border-nest-border/60 rounded-2xl p-4 space-y-1">
        {PROVISION_STEPS.map((step, i) => {
          const isComplete = completedSteps.includes(i);
          const isPending = !isComplete && (i === 0 || completedSteps.includes(i - 1));
          const isWaiting = !isComplete && !isPending;

          return (
            <motion.div
              key={step}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1, duration: 0.25 }}
              className="flex items-center gap-3 px-3 py-3 rounded-xl"
            >
              <div className="relative shrink-0">
                {isComplete ? (
                  <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 500 }}>
                    <div className="w-6 h-6 rounded-full bg-nest-green flex items-center justify-center">
                      <Check className="w-3.5 h-3.5 text-white" />
                    </div>
                  </motion.div>
                ) : isPending ? (
                  <div className="w-6 h-6 rounded-full border-2 border-nest-green/40 border-t-nest-green animate-spin" />
                ) : (
                  <div className="w-6 h-6 rounded-full border border-nest-border" />
                )}
              </div>
              <span className={`text-sm transition-colors duration-300 ${
                isComplete ? 'text-nest-green font-medium' : isPending ? 'text-white/80' : 'text-nest-muted/40'
              }`}>
                {step}
              </span>
              {isComplete && (
                <motion.span
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="ml-auto text-[10px] font-semibold text-nest-green bg-nest-green/10 px-2 py-0.5 rounded-full"
                >
                  Done
                </motion.span>
              )}
            </motion.div>
          );
        })}
      </div>

      {allDone && (
        <motion.button
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          whileTap={{ scale: 0.98 }}
          onClick={onComplete}
          className="w-full bg-gradient-to-br from-nest-green to-emerald-600 text-white font-bold rounded-xl h-12 press-effect transition-all duration-200 shadow-lg shadow-nest-green/25 text-base"
        >
          OK — Go to Dashboard
        </motion.button>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════
// ── Main Component ──────────────────────────────────────────
// ══════════════════════════════════════════════════════════════
export function AddDeviceTab() {
  const { addDeviceStep, setAddDeviceStep, setActiveTab, setDevices } = useAppStore();
  const [direction, setDirection] = useState(1);
  const [selectedDevice, setSelectedDevice] = useState<string | null>(null);

  const goBack = useCallback(() => {
    setDirection(-1);
    if (addDeviceStep === 0) {
      setActiveTab('dashboard');
    } else {
      if (addDeviceStep <= 2) setSelectedDevice(null);
      setAddDeviceStep(addDeviceStep - 1);
    }
  }, [addDeviceStep, setActiveTab, setAddDeviceStep]);

  const goForward = useCallback((step: number) => {
    setDirection(1);
    setAddDeviceStep(step);
  }, [setAddDeviceStep]);

  const handleDeviceSelect = useCallback((name: string) => {
    setSelectedDevice(name);
  }, []);

  const handlePopVerified = useCallback(() => {
    setDirection(1);
    setAddDeviceStep(3);
  }, [setAddDeviceStep]);

  const handleWifiConnected = useCallback(() => {
    setDirection(1);
    setAddDeviceStep(4);
  }, [setAddDeviceStep]);

  const handleProvisionComplete = useCallback(async () => {
    // Refresh devices
    try {
      const res = await fetch('/api/devices');
      if (res.ok) {
        const data = await res.json();
        setDevices(data);
      }
    } catch { /* silent */ }
    toast.success('Device provisioned! 7 new device cards created.');
    setActiveTab('dashboard');
    setAddDeviceStep(0);
    setSelectedDevice(null);
  }, [setActiveTab, setAddDeviceStep, setDevices]);

  const stepTitles = ['Add Device', 'BLE Scan', 'Verify PIN', 'WiFi Setup', 'Provisioning'];

  return (
    <div className="flex flex-col min-h-[calc(100vh-80px)] pb-24">
      {/* ── Header ── */}
      <header className="flex items-center justify-between px-5 pt-5 pb-2">
        <button
          onClick={goBack}
          className="w-10 h-10 rounded-xl bg-nest-card/80 border border-nest-border/60 flex items-center justify-center hover:bg-nest-border/50 transition-all duration-200 press-effect"
        >
          <ArrowLeft className="w-5 h-5 text-nest-muted" />
        </button>
        <h1 className="text-sm font-semibold text-white">{stepTitles[addDeviceStep]}</h1>
        {addDeviceStep > 0 && addDeviceStep < 4 && (
          <button
            onClick={() => { setActiveTab('dashboard'); setAddDeviceStep(0); }}
            className="text-[11px] text-nest-muted/50 hover:text-nest-muted transition-colors"
          >
            Cancel
          </button>
        )}
        {addDeviceStep === 0 || addDeviceStep === 4 ? (
          <div className="w-10" />
        ) : null}
      </header>

      {/* Step dots */}
      {addDeviceStep > 0 && addDeviceStep < 4 && (
        <StepDots current={addDeviceStep - 1} total={3} />
      )}

      {/* ── Content ── */}
      <div className="flex-1 px-5 pt-4">
        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={addDeviceStep}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.35, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            {addDeviceStep === 0 && <EntryStep onSelect={goForward} />}
            {addDeviceStep === 1 && (
              <div>
                <ScanStep selected={selectedDevice} onSelect={handleDeviceSelect} />
                {selectedDevice && (
                  <motion.button
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => goForward(2)}
                    className="w-full mt-4 bg-gradient-to-br from-nest-green to-emerald-600 text-white font-semibold rounded-xl h-12 press-effect transition-all duration-200 shadow-lg shadow-nest-green/20"
                  >
                    Continue with {selectedDevice}
                  </motion.button>
                )}
              </div>
            )}
            {addDeviceStep === 2 && selectedDevice && (
              <PopStep deviceName={selectedDevice} onVerified={handlePopVerified} />
            )}
            {addDeviceStep === 3 && (
              <WifiStep onConnected={handleWifiConnected} />
            )}
            {addDeviceStep === 4 && (
              <ProgressStep onComplete={handleProvisionComplete} />
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}