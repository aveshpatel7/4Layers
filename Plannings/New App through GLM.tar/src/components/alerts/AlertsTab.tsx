'use client';

import { useAppStore, type AlertEvent } from '@/store/use-app-store';
import { Bell, BellOff, CheckCheck, Info, AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useEffect, useCallback, useState } from 'react';

// ── Relative time helper ──
function formatRelativeTime(isoString: string): string {
  const now = Date.now();
  const then = new Date(isoString).getTime();
  const diffMs = now - then;
  const seconds = Math.floor(diffMs / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (seconds < 10) return 'Just now';
  if (seconds < 60) return `${seconds}s ago`;
  if (minutes < 60) return `${minutes}min ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days < 30) return `${days}d ago`;
  return new Date(isoString).toLocaleDateString();
}

// ── Event type config ──
const eventTypeConfig: Record<
  AlertEvent['type'],
  {
    dotColor: string;
    textColor: string;
    borderColor: string;
    glowColor: string;
    icon: typeof Info;
    iconGlowBg: string;
  }
> = {
  success: {
    dotColor: 'bg-nest-green',
    textColor: 'text-nest-green',
    borderColor: 'border-l-nest-green',
    glowColor: 'shadow-[0_0_8px_rgba(34,197,94,0.6)]',
    icon: CheckCircle2,
    iconGlowBg: 'bg-nest-green/10',
  },
  info: {
    dotColor: 'bg-blue-400',
    textColor: 'text-blue-400',
    borderColor: 'border-l-blue-400',
    glowColor: 'shadow-[0_0_8px_rgba(96,165,250,0.6)]',
    icon: Info,
    iconGlowBg: 'bg-blue-400/10',
  },
  warning: {
    dotColor: 'bg-amber-400',
    textColor: 'text-amber-400',
    borderColor: 'border-l-amber-400',
    glowColor: 'shadow-[0_0_8px_rgba(251,191,36,0.6)]',
    icon: AlertTriangle,
    iconGlowBg: 'bg-amber-400/10',
  },
  error: {
    dotColor: 'bg-nest-red',
    textColor: 'text-nest-red',
    borderColor: 'border-l-nest-red',
    glowColor: 'shadow-[0_0_8px_rgba(239,68,68,0.6)]',
    icon: XCircle,
    iconGlowBg: 'bg-nest-red/10',
  },
};

// ── Timeline Card ──
function TimelineCard({ event, index, isLast }: { event: AlertEvent; index: number; isLast: boolean }) {
  const config = eventTypeConfig[event.type];
  const Icon = config.icon;
  const isUnread = !event.isRead;

  return (
    <motion.div
      initial={{ opacity: 0, x: -16 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 16 }}
      transition={{ duration: 0.35, delay: index * 0.06, ease: 'easeOut' }}
      className="relative flex gap-4"
    >
      {/* Timeline rail */}
      <div className="relative flex flex-col items-center shrink-0 w-5">
        <div className="relative mt-2.5 z-10">
          <div
            className={`w-2.5 h-2.5 rounded-full ${config.dotColor} ${
              isUnread ? 'animate-glow-pulse' : ''
            } ${config.glowColor}`}
          />
        </div>
        {!isLast && (
          <div className="w-px flex-1 min-h-[12px] bg-gradient-to-b from-nest-green/15 to-transparent mt-1" />
        )}
      </div>

      {/* Event card */}
      <div
        className={`flex-1 mb-4 rounded-xl border transition-all duration-300 ${
          isUnread
            ? `backdrop-blur-md bg-nest-glass/60 border-l-[3px] ${config.borderColor} border-t-nest-border/50 border-r-nest-border/50 border-b-nest-border/50`
            : 'bg-nest-surface/40 border-nest-border/40 opacity-50'
        }`}
      >
        <div className="flex items-start gap-3 p-3.5">
          {/* Icon */}
          <div className={`shrink-0 w-8 h-8 rounded-full ${config.iconGlowBg} flex items-center justify-center`}>
            <Icon className={`w-4 h-4 ${config.textColor}`} />
          </div>

          <div className="flex-1 min-w-0">
            <p className={`text-[13px] leading-relaxed ${
              isUnread ? 'text-white/85' : 'text-nest-muted/60'
            }`}>
              {event.message}
            </p>

            <div className="flex items-center gap-2 mt-2 flex-wrap">
              {event.deviceName && (
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium tracking-wide ${
                  isUnread ? 'bg-nest-green/8 text-nest-green/70' : 'bg-nest-border/40 text-nest-muted/50'
                }`}>
                  {event.deviceName}
                </span>
              )}
              <span className="text-[10px] font-mono text-nest-muted/40 whitespace-nowrap tracking-tight">
                {formatRelativeTime(event.createdAt)}
              </span>
              {isUnread && (
                <span className="ml-auto w-1.5 h-1.5 rounded-full bg-nest-green shadow-[0_0_6px_rgba(34,197,94,0.5)] shrink-0" />
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ── Empty State ──
function EmptyState() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center py-24 text-center"
    >
      <div className="relative mb-5">
        <div className="w-16 h-16 rounded-2xl bg-nest-surface border border-nest-border/60 flex items-center justify-center animate-float">
          <BellOff className="w-7 h-7 text-nest-muted/30" />
        </div>
        <div className="absolute inset-0 -z-10 rounded-2xl bg-nest-green/5 blur-xl scale-125" />
      </div>
      <p className="text-nest-muted text-sm font-medium">All quiet here</p>
      <p className="text-nest-muted/40 text-xs mt-1.5 max-w-[200px]">
        Device alerts and system events will show up in real time
      </p>
    </motion.div>
  );
}

// ── Main Component ──
export function AlertsTab() {
  const { events, setEvents, unreadCount } = useAppStore();
  const [markingRead, setMarkingRead] = useState(false);

  const fetchEvents = useCallback(async () => {
    try {
      const res = await fetch('/api/events');
      if (res.ok) {
        const data = await res.json();
        setEvents(data);
      }
    } catch {
      // silently fail
    }
  }, [setEvents]);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  const handleMarkAllRead = async () => {
    if (unreadCount === 0 || markingRead) return;
    setMarkingRead(true);
    try {
      await fetch('/api/events', { method: 'PUT' });
      await fetchEvents();
    } catch {
      // silently fail
    } finally {
      setMarkingRead(false);
    }
  };

  return (
    <div className="flex flex-col h-full px-4 pt-4 pb-24">
      {/* ── Header ── */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-nest-glass backdrop-blur-md border border-nest-border/40 flex items-center justify-center">
            <Bell className="w-5 h-5 text-nest-green" />
          </div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-white leading-tight">
              Alerts & Events
            </h1>
            {unreadCount > 0 && (
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-nest-green/12 border border-nest-green/15 text-nest-green text-[10px] font-semibold tabular-nums"
              >
                {unreadCount}
              </motion.span>
            )}
          </div>
        </div>

        <button
          onClick={handleMarkAllRead}
          disabled={unreadCount === 0 || markingRead}
          className="flex items-center gap-1.5 h-8 px-3 rounded-lg text-[11px] font-medium text-nest-muted/60 hover:text-nest-green hover:bg-nest-green/8 transition-all duration-200 disabled:opacity-25 disabled:cursor-not-allowed"
        >
          <CheckCheck className={`w-3.5 h-3.5 ${markingRead ? 'animate-pulse' : 'opacity-60'}`} />
          {markingRead ? 'Updating…' : 'Mark all read'}
        </button>
      </div>

      {/* ── Timeline ── */}
      <div className="flex-1 min-h-0">
        {events.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="max-h-[65vh] overflow-y-auto pr-1 no-scrollbar">
            <AnimatePresence>
              {events.map((event, index) => (
                <TimelineCard
                  key={event.id}
                  event={event}
                  index={index}
                  isLast={index === events.length - 1}
                />
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}