import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SmartNest — IoT Dashboard",
  description: "4Layers SmartNest IoT Eco-system — Control your smart home from anywhere.",
  keywords: ["SmartNest", "IoT", "Smart Home", "4Layers", "ESP32"],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-nest-bg text-nest-text`}
      >
        <div className="gradient-mesh min-h-screen flex flex-col max-w-lg mx-auto relative">
          {children}
        </div>
        <Toaster />
      </body>
    </html>
  );
}