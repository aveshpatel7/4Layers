import { db } from "@/lib/db";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const events = await db.event.findMany({
      include: { device: true },
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    return NextResponse.json(
      events.map((e) => ({
        id: e.id,
        message: e.message,
        type: e.type,
        isRead: e.isRead,
        createdAt: e.createdAt.toISOString(),
        deviceName: e.device?.name,
      }))
    );
  } catch {
    return NextResponse.json({ error: "Failed to fetch events" }, { status: 500 });
  }
}

export async function PUT() {
  try {
    await db.event.updateMany({
      where: { isRead: false },
      data: { isRead: true },
    });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Failed to mark events as read" }, { status: 500 });
  }
}