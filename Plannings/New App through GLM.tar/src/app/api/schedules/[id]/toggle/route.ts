import { db } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const schedule = await db.schedule.findUnique({ where: { id } });
    if (!schedule) {
      return NextResponse.json({ error: "Schedule not found" }, { status: 404 });
    }

    const updated = await db.schedule.update({
      where: { id },
      data: { isEnabled: !schedule.isEnabled },
    });

    return NextResponse.json(updated);
  } catch {
    return NextResponse.json({ error: "Failed to toggle schedule" }, { status: 500 });
  }
}