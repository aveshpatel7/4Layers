import { db } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  try {
    const schedules = await db.schedule.findMany({
      include: { device: { include: { room: true } } },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(schedules);
  } catch {
    return NextResponse.json({ error: "Failed to fetch schedules" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const schedule = await db.schedule.create({
      data: {
        deviceId: body.deviceId,
        userId: body.userId,
        action: body.action || "on",
        days: body.days || "daily",
        timeOn: body.timeOn || null,
        timeOff: body.timeOff || null,
        isEnabled: body.isEnabled ?? true,
      },
    });
    return NextResponse.json(schedule, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Failed to create schedule" }, { status: 500 });
  }
}