import { db } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  try {
    const user = await db.user.findFirst({
      orderBy: { createdAt: "asc" },
    });
    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }
    const { password: _, ...safeUser } = user;
    return NextResponse.json(safeUser);
  } catch {
    return NextResponse.json({ error: "Failed to fetch user" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const user = await db.user.findFirst({
      orderBy: { createdAt: "asc" },
    });
    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // Verify current password
    if (body.currentPassword && body.currentPassword !== user.password) {
      return NextResponse.json({ error: "Current password is incorrect" }, { status: 400 });
    }

    const updated = await db.user.update({
      where: { id: user.id },
      data: {
        name: body.name ?? user.name,
        email: body.email ?? user.email,
        password: body.newPassword ?? user.password,
      },
    });

    const { password: _, ...safeUser } = updated;
    return NextResponse.json(safeUser);
  } catch {
    return NextResponse.json({ error: "Failed to update user" }, { status: 500 });
  }
}