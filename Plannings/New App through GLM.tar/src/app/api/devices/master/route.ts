import { db } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { roomId, isOn } = await req.json();
    const devices = await db.device.findMany({
      where: { roomId },
    });

    const userId = devices[0]?.userId;

    await db.device.updateMany({
      where: { roomId },
      data: { isOn },
    });

    const room = await db.room.findUnique({ where: { id: roomId } });
    if (userId) {
      await db.event.create({
        data: {
          message: `${room?.name || "Room"} Master Switch turned ${isOn ? "ON" : "OFF"}`,
          type: isOn ? "success" : "info",
          userId,
        },
      });
    }

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Failed to toggle master" }, { status: 500 });
  }
}