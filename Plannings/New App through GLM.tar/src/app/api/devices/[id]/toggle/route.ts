import { db } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const device = await db.device.findUnique({ where: { id } });
    if (!device) {
      return NextResponse.json({ error: "Device not found" }, { status: 404 });
    }

    const updated = await db.device.update({
      where: { id },
      data: { isOn: !device.isOn },
    });

    const room = await db.room.findUnique({ where: { id: device.roomId } });
    await db.event.create({
      data: {
        message: `${room?.name || "Room"} ${device.name} turned ${!device.isOn ? "ON" : "OFF"}`,
        type: "success",
        userId: device.userId,
        deviceId: device.id,
      },
    });

    return NextResponse.json(updated);
  } catch {
    return NextResponse.json({ error: "Failed to toggle device" }, { status: 500 });
  }
}