import { db } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { speed } = body;

    const device = await db.device.findUnique({ where: { id } });
    if (!device) {
      return NextResponse.json({ error: "Device not found" }, { status: 404 });
    }

    const updated = await db.device.update({
      where: { id },
      data: { fanSpeed: speed, isOn: speed > 0 },
    });

    const room = await db.room.findUnique({ where: { id: device.roomId } });
    await db.event.create({
      data: {
        message: `${room?.name || "Room"} ${device.name} speed changed to ${speed}`,
        type: "info",
        userId: device.userId,
        deviceId: device.id,
      },
    });

    return NextResponse.json(updated);
  } catch {
    return NextResponse.json({ error: "Failed to update fan speed" }, { status: 500 });
  }
}