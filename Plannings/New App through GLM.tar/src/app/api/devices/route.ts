import { db } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  try {
    const devices = await db.device.findMany({
      include: { room: true },
      orderBy: { createdAt: "asc" },
    });
    return NextResponse.json(devices);
  } catch {
    return NextResponse.json({ error: "Failed to fetch devices" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const device = await db.device.create({
      data: {
        name: body.name,
        type: body.type || "relay",
        relayIndex: body.relayIndex ?? null,
        isOn: body.isOn ?? false,
        roomId: body.roomId,
        userId: body.userId,
        nodeMac: body.nodeMac || null,
      },
    });
    return NextResponse.json(device, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Failed to create device" }, { status: 500 });
  }
}