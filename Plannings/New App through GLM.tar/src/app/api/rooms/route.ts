import { db } from "@/lib/db";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const rooms = await db.room.findMany({
      orderBy: { createdAt: "asc" },
    });
    return NextResponse.json(rooms);
  } catch {
    return NextResponse.json({ error: "Failed to fetch rooms" }, { status: 500 });
  }
}