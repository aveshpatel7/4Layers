'use client';

import { useEffect, useCallback } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useAppStore } from '@/store/use-app-store';
import { BottomNav } from '@/components/layout/BottomNav';
import { DashboardTab } from '@/components/dashboard/DashboardTab';
import { AddDeviceTab } from '@/components/add-device/AddDeviceTab';
import { TimersTab } from '@/components/timers/TimersTab';
import { AlertsTab } from '@/components/alerts/AlertsTab';
import { SettingsTab } from '@/components/settings/SettingsTab';

const pageVariants = {
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -8 },
};

const pageTransition = { duration: 0.25, ease: [0.25, 0.46, 0.45, 0.94] as const };

export default function Home() {
  const {
    activeTab, setRooms, setDevices, setEvents, setSchedules,
  } = useAppStore();

  const fetchInitialData = useCallback(async () => {
    try {
      const [roomsRes, devicesRes, eventsRes, schedulesRes] = await Promise.all([
        fetch('/api/rooms'),
        fetch('/api/devices'),
        fetch('/api/events'),
        fetch('/api/schedules'),
      ]);

      if (roomsRes.ok) {
        const roomsData = await roomsRes.json();
        setRooms(roomsData);
      }
      if (devicesRes.ok) {
        const devicesData = await devicesRes.json();
        setDevices(devicesData);
      }
      if (eventsRes.ok) {
        const eventsData = await eventsRes.json();
        setEvents(eventsData);
      }
      if (schedulesRes.ok) {
        const schedulesData = await schedulesRes.json();
        setSchedules(schedulesData);
      }
    } catch {
      // silent fail — data will be empty
    }
  }, [setRooms, setDevices, setEvents, setSchedules]);

  useEffect(() => {
    fetchInitialData();
  }, [fetchInitialData]);

  const renderTab = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardTab />;
      case 'add-device':
        return <AddDeviceTab />;
      case 'timers':
        return <TimersTab />;
      case 'alerts':
        return <AlertsTab />;
      case 'settings':
        return <SettingsTab />;
      default:
        return <DashboardTab />;
    }
  };

  return (
    <main className="flex-1 overflow-y-auto no-scrollbar">
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          variants={pageVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          transition={pageTransition}
        >
          {renderTab()}
        </motion.div>
      </AnimatePresence>
      <BottomNav />
    </main>
  );
}